CREATE TABLE `portfolio_targets` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`targetType` enum('sector','ticker') NOT NULL,
	`targetKey` varchar(100) NOT NULL,
	`label` varchar(200) NOT NULL,
	`targetWeight` decimal(8,4) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `portfolio_targets_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `price_alerts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`holdingId` int,
	`ticker` varchar(20) NOT NULL,
	`name` varchar(200) NOT NULL,
	`alertType` enum('price_above','price_below','return_above','return_below') NOT NULL,
	`targetValue` decimal(18,4) NOT NULL,
	`triggered` enum('no','yes') NOT NULL DEFAULT 'no',
	`triggeredAt` timestamp,
	`status` enum('active','paused') NOT NULL DEFAULT 'active',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `price_alerts_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE INDEX `targets_userId_idx` ON `portfolio_targets` (`userId`);--> statement-breakpoint
CREATE INDEX `alerts_userId_idx` ON `price_alerts` (`userId`);--> statement-breakpoint
CREATE INDEX `alerts_ticker_idx` ON `price_alerts` (`ticker`);--> statement-breakpoint
CREATE INDEX `alerts_status_idx` ON `price_alerts` (`status`);