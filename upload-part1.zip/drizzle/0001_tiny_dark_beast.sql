CREATE TABLE `holdings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`ticker` varchar(20) NOT NULL,
	`name` varchar(200) NOT NULL,
	`quantity` decimal(18,6) NOT NULL,
	`avgPrice` decimal(18,4) NOT NULL,
	`currentPrice` decimal(18,4) DEFAULT '0',
	`sector` varchar(100),
	`market` varchar(50),
	`currency` varchar(10) DEFAULT 'KRW',
	`dividendYield` decimal(8,4) DEFAULT '0',
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `holdings_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `portfolio_snapshots` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`totalInvested` decimal(18,4) NOT NULL,
	`totalValue` decimal(18,4) NOT NULL,
	`totalReturn` decimal(12,4) NOT NULL,
	`returnRate` decimal(10,4) NOT NULL,
	`snapshotDate` timestamp NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `portfolio_snapshots_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `transactions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`holdingId` int NOT NULL,
	`type` enum('buy','sell') NOT NULL,
	`quantity` decimal(18,6) NOT NULL,
	`price` decimal(18,4) NOT NULL,
	`totalAmount` decimal(18,4) NOT NULL,
	`fee` decimal(18,4) DEFAULT '0',
	`notes` text,
	`transactionDate` timestamp NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `transactions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE INDEX `holdings_userId_idx` ON `holdings` (`userId`);--> statement-breakpoint
CREATE INDEX `holdings_ticker_idx` ON `holdings` (`ticker`);--> statement-breakpoint
CREATE INDEX `snapshots_userId_idx` ON `portfolio_snapshots` (`userId`);--> statement-breakpoint
CREATE INDEX `snapshots_date_idx` ON `portfolio_snapshots` (`snapshotDate`);--> statement-breakpoint
CREATE INDEX `transactions_userId_idx` ON `transactions` (`userId`);--> statement-breakpoint
CREATE INDEX `transactions_holdingId_idx` ON `transactions` (`holdingId`);--> statement-breakpoint
CREATE INDEX `transactions_date_idx` ON `transactions` (`transactionDate`);