import {
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  varchar,
  decimal,
  bigint,
  index,
} from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Holdings - 사용자의 보유 종목 정보
 */
export const holdings = mysqlTable(
  "holdings",
  {
    id: int("id").autoincrement().primaryKey(),
    userId: int("userId").notNull(),
    ticker: varchar("ticker", { length: 20 }).notNull(),
    name: varchar("name", { length: 200 }).notNull(),
    quantity: decimal("quantity", { precision: 18, scale: 6 }).notNull(),
    avgPrice: decimal("avgPrice", { precision: 18, scale: 4 }).notNull(),
    currentPrice: decimal("currentPrice", { precision: 18, scale: 4 }).default("0"),
    sector: varchar("sector", { length: 100 }),
    market: varchar("market", { length: 50 }),
    currency: varchar("currency", { length: 10 }).default("KRW"),
    dividendYield: decimal("dividendYield", { precision: 8, scale: 4 }).default("0"),
    notes: text("notes"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  (table) => [
    index("holdings_userId_idx").on(table.userId),
    index("holdings_ticker_idx").on(table.ticker),
  ]
);

export type Holding = typeof holdings.$inferSelect;
export type InsertHolding = typeof holdings.$inferInsert;

/**
 * Transactions - 매수/매도 거래 이력
 */
export const transactions = mysqlTable(
  "transactions",
  {
    id: int("id").autoincrement().primaryKey(),
    userId: int("userId").notNull(),
    holdingId: int("holdingId").notNull(),
    type: mysqlEnum("type", ["buy", "sell"]).notNull(),
    quantity: decimal("quantity", { precision: 18, scale: 6 }).notNull(),
    price: decimal("price", { precision: 18, scale: 4 }).notNull(),
    totalAmount: decimal("totalAmount", { precision: 18, scale: 4 }).notNull(),
    fee: decimal("fee", { precision: 18, scale: 4 }).default("0"),
    notes: text("notes"),
    transactionDate: timestamp("transactionDate").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => [
    index("transactions_userId_idx").on(table.userId),
    index("transactions_holdingId_idx").on(table.holdingId),
    index("transactions_date_idx").on(table.transactionDate),
  ]
);

export type Transaction = typeof transactions.$inferSelect;
export type InsertTransaction = typeof transactions.$inferInsert;

/**
 * Portfolio Snapshots - 일별 포트폴리오 가치 스냅샷 (성과 차트용)
 */
export const portfolioSnapshots = mysqlTable(
  "portfolio_snapshots",
  {
    id: int("id").autoincrement().primaryKey(),
    userId: int("userId").notNull(),
    totalInvested: decimal("totalInvested", { precision: 18, scale: 4 }).notNull(),
    totalValue: decimal("totalValue", { precision: 18, scale: 4 }).notNull(),
    totalReturn: decimal("totalReturn", { precision: 12, scale: 4 }).notNull(),
    returnRate: decimal("returnRate", { precision: 10, scale: 4 }).notNull(),
    snapshotDate: timestamp("snapshotDate").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => [
    index("snapshots_userId_idx").on(table.userId),
    index("snapshots_date_idx").on(table.snapshotDate),
  ]
);

export type PortfolioSnapshot = typeof portfolioSnapshots.$inferSelect;
export type InsertPortfolioSnapshot = typeof portfolioSnapshots.$inferInsert;

/**
 * Portfolio Targets - 목표 포트폴리오 비중 설정 (리밸런싱 가이드용)
 */
export const portfolioTargets = mysqlTable(
  "portfolio_targets",
  {
    id: int("id").autoincrement().primaryKey(),
    userId: int("userId").notNull(),
    /** 'sector' or 'ticker' */
    targetType: mysqlEnum("targetType", ["sector", "ticker"]).notNull(),
    /** sector name or ticker symbol */
    targetKey: varchar("targetKey", { length: 100 }).notNull(),
    /** display label */
    label: varchar("label", { length: 200 }).notNull(),
    /** target weight percentage 0-100 */
    targetWeight: decimal("targetWeight", { precision: 8, scale: 4 }).notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  (table) => [
    index("targets_userId_idx").on(table.userId),
  ]
);

export type PortfolioTarget = typeof portfolioTargets.$inferSelect;
export type InsertPortfolioTarget = typeof portfolioTargets.$inferInsert;

/**
 * Price Alerts - 가격 알림 설정
 */
export const priceAlerts = mysqlTable(
  "price_alerts",
  {
    id: int("id").autoincrement().primaryKey(),
    userId: int("userId").notNull(),
    holdingId: int("holdingId"),
    ticker: varchar("ticker", { length: 20 }).notNull(),
    name: varchar("name", { length: 200 }).notNull(),
    /** 'price_above', 'price_below', 'return_above', 'return_below' */
    alertType: mysqlEnum("alertType", [
      "price_above",
      "price_below",
      "return_above",
      "return_below",
    ]).notNull(),
    /** target value (price or return percentage) */
    targetValue: decimal("targetValue", { precision: 18, scale: 4 }).notNull(),
    /** whether alert has been triggered */
    triggered: mysqlEnum("triggered", ["no", "yes"]).default("no").notNull(),
    triggeredAt: timestamp("triggeredAt"),
    /** active or paused */
    status: mysqlEnum("status", ["active", "paused"]).default("active").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  (table) => [
    index("alerts_userId_idx").on(table.userId),
    index("alerts_ticker_idx").on(table.ticker),
    index("alerts_status_idx").on(table.status),
  ]
);

export type PriceAlert = typeof priceAlerts.$inferSelect;
export type InsertPriceAlert = typeof priceAlerts.$inferInsert;
