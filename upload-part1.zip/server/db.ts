import { eq, and, desc, asc, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  InsertUser,
  users,
  holdings,
  transactions,
  portfolioSnapshots,
  portfolioTargets,
  priceAlerts,
  type InsertHolding,
  type InsertTransaction,
  type InsertPortfolioSnapshot,
  type InsertPortfolioTarget,
  type InsertPriceAlert,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ─── User helpers ───────────────────────────────────────────────────

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }
  try {
    const values: InsertUser = { openId: user.openId };
    const updateSet: Record<string, unknown> = {};
    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];
    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };
    textFields.forEach(assignNullable);
    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = "admin";
      updateSet.role = "admin";
    }
    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }
    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }
    await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// ─── Holdings helpers ───────────────────────────────────────────────

export async function getHoldingsByUser(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(holdings)
    .where(eq(holdings.userId, userId))
    .orderBy(desc(holdings.updatedAt));
}

export async function getHoldingById(holdingId: number, userId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db
    .select()
    .from(holdings)
    .where(and(eq(holdings.id, holdingId), eq(holdings.userId, userId)))
    .limit(1);
  return result[0];
}

export async function createHolding(data: InsertHolding) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(holdings).values(data);
  return result[0].insertId;
}

export async function updateHolding(
  holdingId: number,
  userId: number,
  data: Partial<Omit<InsertHolding, "id" | "userId" | "createdAt">>
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db
    .update(holdings)
    .set(data)
    .where(and(eq(holdings.id, holdingId), eq(holdings.userId, userId)));
}

export async function deleteHolding(holdingId: number, userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  // Delete related transactions first
  await db
    .delete(transactions)
    .where(and(eq(transactions.holdingId, holdingId), eq(transactions.userId, userId)));
  await db
    .delete(holdings)
    .where(and(eq(holdings.id, holdingId), eq(holdings.userId, userId)));
}

// ─── Transactions helpers ───────────────────────────────────────────

export async function getTransactionsByHolding(holdingId: number, userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(transactions)
    .where(and(eq(transactions.holdingId, holdingId), eq(transactions.userId, userId)))
    .orderBy(desc(transactions.transactionDate));
}

export async function getTransactionsByUser(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(transactions)
    .where(eq(transactions.userId, userId))
    .orderBy(desc(transactions.transactionDate));
}

export async function createTransaction(data: InsertTransaction) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(transactions).values(data);
  return result[0].insertId;
}

export async function deleteTransaction(transactionId: number, userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db
    .delete(transactions)
    .where(and(eq(transactions.id, transactionId), eq(transactions.userId, userId)));
}

// ─── Portfolio Snapshots helpers ────────────────────────────────────

export async function getPortfolioSnapshots(userId: number, limit = 90) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(portfolioSnapshots)
    .where(eq(portfolioSnapshots.userId, userId))
    .orderBy(asc(portfolioSnapshots.snapshotDate))
    .limit(limit);
}

export async function createPortfolioSnapshot(data: InsertPortfolioSnapshot) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(portfolioSnapshots).values(data);
}

// ─── Portfolio Summary helpers ──────────────────────────────────────

export async function getPortfolioSummary(userId: number) {
  const db = await getDb();
  if (!db) return { totalInvested: 0, totalValue: 0, totalReturn: 0, returnRate: 0, holdingsCount: 0 };

  const userHoldings = await db
    .select()
    .from(holdings)
    .where(eq(holdings.userId, userId));

  let totalInvested = 0;
  let totalValue = 0;

  for (const h of userHoldings) {
    const qty = Number(h.quantity);
    const avg = Number(h.avgPrice);
    const cur = Number(h.currentPrice) || avg;
    totalInvested += qty * avg;
    totalValue += qty * cur;
  }

  const totalReturn = totalValue - totalInvested;
  const returnRate = totalInvested > 0 ? (totalReturn / totalInvested) * 100 : 0;

  return {
    totalInvested,
    totalValue,
    totalReturn,
    returnRate,
    holdingsCount: userHoldings.length,
  };
}

// ─── Portfolio Targets helpers ──────────────────────────────────────────

export async function getTargetsByUser(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(portfolioTargets)
    .where(eq(portfolioTargets.userId, userId))
    .orderBy(desc(portfolioTargets.targetWeight));
}

export async function createTarget(data: InsertPortfolioTarget) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(portfolioTargets).values(data);
  return result[0].insertId;
}

export async function updateTarget(
  targetId: number,
  userId: number,
  data: Partial<Omit<InsertPortfolioTarget, "id" | "userId" | "createdAt">>
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db
    .update(portfolioTargets)
    .set(data)
    .where(and(eq(portfolioTargets.id, targetId), eq(portfolioTargets.userId, userId)));
}

export async function deleteTarget(targetId: number, userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db
    .delete(portfolioTargets)
    .where(and(eq(portfolioTargets.id, targetId), eq(portfolioTargets.userId, userId)));
}

// ─── Price Alerts helpers ─────────────────────────────────────────────

export async function getAlertsByUser(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(priceAlerts)
    .where(eq(priceAlerts.userId, userId))
    .orderBy(desc(priceAlerts.createdAt));
}

export async function getActiveAlerts(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(priceAlerts)
    .where(and(eq(priceAlerts.userId, userId), eq(priceAlerts.status, "active"), eq(priceAlerts.triggered, "no")));
}

export async function createAlert(data: InsertPriceAlert) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(priceAlerts).values(data);
  return result[0].insertId;
}

export async function updateAlert(
  alertId: number,
  userId: number,
  data: Partial<Omit<InsertPriceAlert, "id" | "userId" | "createdAt">>
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db
    .update(priceAlerts)
    .set(data)
    .where(and(eq(priceAlerts.id, alertId), eq(priceAlerts.userId, userId)));
}

export async function deleteAlert(alertId: number, userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db
    .delete(priceAlerts)
    .where(and(eq(priceAlerts.id, alertId), eq(priceAlerts.userId, userId)));
}
