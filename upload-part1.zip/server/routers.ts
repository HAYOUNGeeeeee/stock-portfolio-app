import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { callDataApi } from "./_core/dataApi";
import {
  getHoldingsByUser,
  getHoldingById,
  createHolding,
  updateHolding,
  deleteHolding,
  getTransactionsByHolding,
  getTransactionsByUser,
  createTransaction,
  deleteTransaction,
  getPortfolioSnapshots,
  createPortfolioSnapshot,
  getPortfolioSummary,
  getTargetsByUser,
  createTarget,
  updateTarget,
  deleteTarget,
  getAlertsByUser,
  getActiveAlerts,
  createAlert,
  updateAlert,
  deleteAlert,
} from "./db";
import { notifyOwner } from "./_core/notification";

// ─── Stock Price Cache (5 min TTL) ──────────────────────────────────
const priceCache = new Map<string, { price: number; change: number; changePercent: number; name: string; currency: string; ts: number }>();
const CACHE_TTL = 5 * 60 * 1000; // 5 minutes

async function fetchStockPrice(ticker: string) {
  const cached = priceCache.get(ticker);
  if (cached && Date.now() - cached.ts < CACHE_TTL) return cached;

  // Try to normalize ticker for Korean stocks
  const symbolsToTry = [ticker.toUpperCase()];
  if (/^\d{6}$/.test(ticker)) {
    symbolsToTry.push(`${ticker}.KS`, `${ticker}.KQ`);
  }

  for (const symbol of symbolsToTry) {
    try {
      const result = await callDataApi("YahooFinance/get_stock_chart", {
        query: {
          symbol: symbol,
          interval: "1d",
          range: "5d",
          includeAdjustedClose: true,
        },
      }) as any;

      if (result?.chart?.result?.[0]) {
        const meta = result.chart.result[0].meta;
        const price = meta.regularMarketPrice ?? 0;
        const prevClose = meta.chartPreviousClose ?? meta.previousClose ?? price;
        const change = price - prevClose;
        const changePercent = prevClose > 0 ? (change / prevClose) * 100 : 0;

        const entry = {
          price,
          change,
          changePercent,
          name: meta.longName || meta.shortName || ticker,
          currency: meta.currency || "USD",
          ts: Date.now(),
        };
        priceCache.set(ticker, entry);
        return entry;
      }
    } catch (err) {
      console.warn(`[StockPrice] Failed to fetch ${symbol}:`, err);
    }
  }
  return null;
}

async function fetchStockHistory(ticker: string, range: string = "1y") {
  try {
    const result = await callDataApi("YahooFinance/get_stock_chart", {
      query: {
        symbol: ticker,
        interval: range === "5y" ? "1mo" : "1wk",
        range,
        includeAdjustedClose: true,
      },
    }) as any;

    if (result?.chart?.result?.[0]) {
      const data = result.chart.result[0];
      const timestamps = data.timestamp || [];
      const quotes = data.indicators?.quote?.[0] || {};
      const adjClose = data.indicators?.adjclose?.[0]?.adjclose || [];

      return timestamps.map((ts: number, i: number) => ({
        date: new Date(ts * 1000).toISOString().split("T")[0],
        open: quotes.open?.[i] ?? null,
        high: quotes.high?.[i] ?? null,
        low: quotes.low?.[i] ?? null,
        close: quotes.close?.[i] ?? null,
        adjClose: adjClose[i] ?? quotes.close?.[i] ?? null,
        volume: quotes.volume?.[i] ?? 0,
      })).filter((d: any) => d.close !== null);
    }
  } catch (err) {
    console.warn(`[StockHistory] Failed to fetch ${ticker}:`, err);
  }
  return [];
}

// ─── 5-Year Scenario Analysis ────────────────────────────────────────
function calculateScenarios(
  currentPrice: number,
  historicalPrices: number[],
  dividendYield: number
) {
  // Calculate historical annual return and volatility
  const returns: number[] = [];
  for (let i = 1; i < historicalPrices.length; i++) {
    if (historicalPrices[i - 1] > 0) {
      returns.push((historicalPrices[i] - historicalPrices[i - 1]) / historicalPrices[i - 1]);
    }
  }

  const avgReturn = returns.length > 0 ? returns.reduce((a, b) => a + b, 0) / returns.length : 0.05;
  const variance = returns.length > 1
    ? returns.reduce((sum, r) => sum + (r - avgReturn) ** 2, 0) / (returns.length - 1)
    : 0.04;
  const volatility = Math.sqrt(variance);

  // Annualize (assuming monthly data)
  const annualReturn = avgReturn * 12;
  const annualVolatility = volatility * Math.sqrt(12);

  const years = [1, 2, 3, 4, 5];
  const divYield = dividendYield / 100;

  // Three scenarios
  const scenarios = {
    optimistic: years.map((y) => {
      const growthRate = annualReturn + annualVolatility;
      const priceGrowth = currentPrice * Math.pow(1 + growthRate, y);
      const cumulativeDividend = currentPrice * divYield * y * (1 + growthRate * y / 2);
      return {
        year: y,
        price: Math.round(priceGrowth * 100) / 100,
        totalReturn: Math.round(((priceGrowth - currentPrice + cumulativeDividend) / currentPrice) * 10000) / 100,
        dividend: Math.round(cumulativeDividend * 100) / 100,
      };
    }),
    neutral: years.map((y) => {
      const growthRate = annualReturn;
      const priceGrowth = currentPrice * Math.pow(1 + growthRate, y);
      const cumulativeDividend = currentPrice * divYield * y;
      return {
        year: y,
        price: Math.round(priceGrowth * 100) / 100,
        totalReturn: Math.round(((priceGrowth - currentPrice + cumulativeDividend) / currentPrice) * 10000) / 100,
        dividend: Math.round(cumulativeDividend * 100) / 100,
      };
    }),
    pessimistic: years.map((y) => {
      const growthRate = annualReturn - annualVolatility;
      const priceGrowth = currentPrice * Math.pow(1 + growthRate, y);
      const cumulativeDividend = currentPrice * divYield * y * Math.max(0.5, 1 + growthRate * y / 2);
      return {
        year: y,
        price: Math.round(priceGrowth * 100) / 100,
        totalReturn: Math.round(((priceGrowth - currentPrice + cumulativeDividend) / currentPrice) * 10000) / 100,
        dividend: Math.round(cumulativeDividend * 100) / 100,
      };
    }),
  };

  return {
    currentPrice,
    annualReturn: Math.round(annualReturn * 10000) / 100,
    annualVolatility: Math.round(annualVolatility * 10000) / 100,
    dividendYield,
    scenarios,
  };
}

export const appRouter = router({
  system: systemRouter,

  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  // ─── Stock Price (Real-time) ──────────────────────────────────────
  stock: router({
    getPrice: protectedProcedure
      .input(z.object({ ticker: z.string() }))
      .query(async ({ input }) => {
        return fetchStockPrice(input.ticker);
      }),

    getPrices: protectedProcedure
      .input(z.object({ tickers: z.array(z.string()) }))
      .query(async ({ input }) => {
        const results: Record<string, { price: number; change: number; changePercent: number; name: string; currency: string } | null> = {};
        await Promise.all(
          input.tickers.map(async (ticker) => {
            results[ticker] = await fetchStockPrice(ticker);
          })
        );
        return results;
      }),

    getHistory: protectedProcedure
      .input(z.object({ ticker: z.string(), range: z.string().optional() }))
      .query(async ({ input }) => {
        return fetchStockHistory(input.ticker, input.range || "1y");
      }),

    getScenario: protectedProcedure
      .input(
        z.object({
          ticker: z.string(),
          currentPrice: z.number(),
          dividendYield: z.number().optional(),
        })
      )
      .query(async ({ input }) => {
        const history = await fetchStockHistory(input.ticker, "5y");
        const prices = history.map((h: any) => h.close).filter((p: number) => p > 0);
        return calculateScenarios(
          input.currentPrice,
          prices.length > 0 ? prices : [input.currentPrice],
          input.dividendYield || 0
        );
      }),

    refreshAll: protectedProcedure.mutation(async ({ ctx }) => {
      const userHoldings = await getHoldingsByUser(ctx.user.id);
      const updated: { id: number; ticker: string; newPrice: number }[] = [];

      await Promise.all(
        userHoldings.map(async (h) => {
          const priceData = await fetchStockPrice(h.ticker);
          if (priceData && priceData.price > 0) {
            await updateHolding(h.id, ctx.user.id, {
              currentPrice: String(priceData.price),
            });
            updated.push({ id: h.id, ticker: h.ticker, newPrice: priceData.price });
          }
        })
      );

      return { updated, count: updated.length };
    }),
  }),

  // ─── Holdings ─────────────────────────────────────────────────────
  holdings: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return getHoldingsByUser(ctx.user.id);
    }),

    getById: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ ctx, input }) => {
        return getHoldingById(input.id, ctx.user.id);
      }),

    create: protectedProcedure
      .input(
        z.object({
          ticker: z.string().min(1).max(20),
          name: z.string().min(1).max(200),
          quantity: z.string(),
          avgPrice: z.string(),
          currentPrice: z.string().optional(),
          sector: z.string().max(100).optional(),
          market: z.string().max(50).optional(),
          currency: z.string().max(10).optional(),
          dividendYield: z.string().optional(),
          notes: z.string().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        // Try to fetch real-time price
        let currentPrice = input.currentPrice || input.avgPrice;
        try {
          const priceData = await fetchStockPrice(input.ticker.toUpperCase());
          if (priceData && priceData.price > 0) {
            currentPrice = String(priceData.price);
          }
        } catch {}

        const holdingId = await createHolding({
          userId: ctx.user.id,
          ticker: input.ticker.toUpperCase(),
          name: input.name,
          quantity: input.quantity,
          avgPrice: input.avgPrice,
          currentPrice,
          sector: input.sector || null,
          market: input.market || null,
          currency: input.currency || "KRW",
          dividendYield: input.dividendYield || "0",
          notes: input.notes || null,
        });

        await createTransaction({
          userId: ctx.user.id,
          holdingId,
          type: "buy",
          quantity: input.quantity,
          price: input.avgPrice,
          totalAmount: String(Number(input.quantity) * Number(input.avgPrice)),
          fee: "0",
          transactionDate: new Date(),
        });

        return { id: holdingId };
      }),

    update: protectedProcedure
      .input(
        z.object({
          id: z.number(),
          ticker: z.string().min(1).max(20).optional(),
          name: z.string().min(1).max(200).optional(),
          quantity: z.string().optional(),
          avgPrice: z.string().optional(),
          currentPrice: z.string().optional(),
          sector: z.string().max(100).optional(),
          market: z.string().max(50).optional(),
          currency: z.string().max(10).optional(),
          dividendYield: z.string().optional(),
          notes: z.string().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const { id, ...data } = input;
        const updateData: Record<string, unknown> = {};
        if (data.ticker !== undefined) updateData.ticker = data.ticker.toUpperCase();
        if (data.name !== undefined) updateData.name = data.name;
        if (data.quantity !== undefined) updateData.quantity = data.quantity;
        if (data.avgPrice !== undefined) updateData.avgPrice = data.avgPrice;
        if (data.currentPrice !== undefined) updateData.currentPrice = data.currentPrice;
        if (data.sector !== undefined) updateData.sector = data.sector;
        if (data.market !== undefined) updateData.market = data.market;
        if (data.currency !== undefined) updateData.currency = data.currency;
        if (data.dividendYield !== undefined) updateData.dividendYield = data.dividendYield;
        if (data.notes !== undefined) updateData.notes = data.notes;
        await updateHolding(id, ctx.user.id, updateData);
        return { success: true };
      }),

    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ ctx, input }) => {
        await deleteHolding(input.id, ctx.user.id);
        return { success: true };
      }),
  }),

  // ─── Transactions ─────────────────────────────────────────────────
  transactions: router({
    listByHolding: protectedProcedure
      .input(z.object({ holdingId: z.number() }))
      .query(async ({ ctx, input }) => {
        return getTransactionsByHolding(input.holdingId, ctx.user.id);
      }),

    listAll: protectedProcedure.query(async ({ ctx }) => {
      return getTransactionsByUser(ctx.user.id);
    }),

    create: protectedProcedure
      .input(
        z.object({
          holdingId: z.number(),
          type: z.enum(["buy", "sell"]),
          quantity: z.string(),
          price: z.string(),
          fee: z.string().optional(),
          notes: z.string().optional(),
          transactionDate: z.date(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const totalAmount = String(Number(input.quantity) * Number(input.price));
        const txId = await createTransaction({
          userId: ctx.user.id,
          holdingId: input.holdingId,
          type: input.type,
          quantity: input.quantity,
          price: input.price,
          totalAmount,
          fee: input.fee || "0",
          notes: input.notes || null,
          transactionDate: input.transactionDate,
        });

        const holding = await getHoldingById(input.holdingId, ctx.user.id);
        if (holding) {
          const currentQty = Number(holding.quantity);
          const currentAvg = Number(holding.avgPrice);
          const txQty = Number(input.quantity);
          const txPrice = Number(input.price);

          if (input.type === "buy") {
            const newQty = currentQty + txQty;
            const newAvg = newQty > 0 ? (currentQty * currentAvg + txQty * txPrice) / newQty : 0;
            await updateHolding(input.holdingId, ctx.user.id, {
              quantity: String(newQty),
              avgPrice: String(newAvg),
            });
          } else {
            const newQty = Math.max(0, currentQty - txQty);
            await updateHolding(input.holdingId, ctx.user.id, {
              quantity: String(newQty),
            });
          }
        }

        return { id: txId };
      }),

    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ ctx, input }) => {
        await deleteTransaction(input.id, ctx.user.id);
        return { success: true };
      }),
  }),

  // ─── Portfolio ────────────────────────────────────────────────────
  portfolio: router({
    summary: protectedProcedure.query(async ({ ctx }) => {
      return getPortfolioSummary(ctx.user.id);
    }),

    snapshots: protectedProcedure
      .input(z.object({ limit: z.number().min(1).max(365).optional() }).optional())
      .query(async ({ ctx, input }) => {
        return getPortfolioSnapshots(ctx.user.id, input?.limit || 90);
      }),

    saveSnapshot: protectedProcedure.mutation(async ({ ctx }) => {
      const summary = await getPortfolioSummary(ctx.user.id);
      await createPortfolioSnapshot({
        userId: ctx.user.id,
        totalInvested: String(summary.totalInvested),
        totalValue: String(summary.totalValue),
        totalReturn: String(summary.totalReturn),
        returnRate: String(summary.returnRate),
        snapshotDate: new Date(),
      });
      return { success: true };
    }),
  }),

  // ─── CSV Export/Import ───────────────────────────────────────────
  csv: router({
    exportHoldings: protectedProcedure.query(async ({ ctx }) => {
      const userHoldings = await getHoldingsByUser(ctx.user.id);
      const header = "ticker,name,quantity,avgPrice,currentPrice,sector,market,currency,dividendYield,notes";
      const rows = userHoldings.map((h) =>
        [
          h.ticker,
          `"${(h.name || "").replace(/"/g, '""')}"`,
          h.quantity,
          h.avgPrice,
          h.currentPrice || "",
          `"${(h.sector || "").replace(/"/g, '""')}"`,
          h.market || "",
          h.currency || "KRW",
          h.dividendYield || "0",
          `"${(h.notes || "").replace(/"/g, '""')}"`,
        ].join(",")
      );
      return { csv: [header, ...rows].join("\n"), filename: `holdings_${new Date().toISOString().split("T")[0]}.csv` };
    }),

    exportTransactions: protectedProcedure.query(async ({ ctx }) => {
      const txs = await getTransactionsByUser(ctx.user.id);
      const header = "ticker,type,quantity,price,totalAmount,fee,notes,transactionDate";
      // We need holding info for ticker
      const userHoldings = await getHoldingsByUser(ctx.user.id);
      const holdingMap = new Map(userHoldings.map((h) => [h.id, h]));
      const rows = txs.map((t) => {
        const holding = holdingMap.get(t.holdingId);
        return [
          holding?.ticker || "",
          t.type,
          t.quantity,
          t.price,
          t.totalAmount,
          t.fee || "0",
          `"${(t.notes || "").replace(/"/g, '""')}"`,
          new Date(t.transactionDate).toISOString().split("T")[0],
        ].join(",");
      });
      return { csv: [header, ...rows].join("\n"), filename: `transactions_${new Date().toISOString().split("T")[0]}.csv` };
    }),

    importHoldings: protectedProcedure
      .input(z.object({ csvContent: z.string() }))
      .mutation(async ({ ctx, input }) => {
        const lines = input.csvContent.trim().split("\n");
        if (lines.length < 2) return { imported: 0, errors: ["CSV 파일이 비어있거나 헤더만 있습니다"] };

        const header = lines[0].toLowerCase();
        const cols = header.split(",").map((c) => c.trim());
        const tickerIdx = cols.indexOf("ticker");
        const nameIdx = cols.indexOf("name");
        const qtyIdx = cols.indexOf("quantity");
        const avgIdx = cols.indexOf("avgprice");
        const curIdx = cols.indexOf("currentprice");
        const sectorIdx = cols.indexOf("sector");
        const marketIdx = cols.indexOf("market");
        const currencyIdx = cols.indexOf("currency");
        const divIdx = cols.indexOf("dividendyield");

        if (tickerIdx === -1 || nameIdx === -1 || qtyIdx === -1 || avgIdx === -1) {
          return { imported: 0, errors: ["필수 컨럼(ticker, name, quantity, avgPrice)이 누락되었습니다"] };
        }

        let imported = 0;
        const errors: string[] = [];

        for (let i = 1; i < lines.length; i++) {
          try {
            const row = parseCSVRow(lines[i]);
            if (row.length < 4) { errors.push(`행 ${i + 1}: 데이터 부족`); continue; }

            const ticker = row[tickerIdx]?.trim();
            const name = row[nameIdx]?.trim();
            const quantity = row[qtyIdx]?.trim();
            const avgPrice = row[avgIdx]?.trim();

            if (!ticker || !name || !quantity || !avgPrice) {
              errors.push(`행 ${i + 1}: 필수 데이터 누락`);
              continue;
            }

            // Try to fetch real-time price and sector
            let currentPrice = curIdx >= 0 ? row[curIdx]?.trim() || avgPrice : avgPrice;
            let sector = sectorIdx >= 0 ? row[sectorIdx]?.trim() || null : null;
            
            try {
              const priceData = await fetchStockPrice(ticker);
              if (priceData) {
                if (priceData.price > 0) currentPrice = String(priceData.price);
                // Simple sector guessing if not provided
                if (!sector) {
                  const n = name.toLowerCase();
                  if (n.includes("전자") || n.includes("반도체") || n.includes("하이닉스")) sector = "IT/반도체";
                  else if (n.includes("은행") || n.includes("금융") || n.includes("증권") || n.includes("생명") || n.includes("화재")) sector = "금융";
                  else if (n.includes("자동차") || n.includes("모빌리티") || n.includes("현대차") || n.includes("기아")) sector = "자동차";
                  else if (n.includes("바이오") || n.includes("제약") || n.includes("셀트리온")) sector = "바이오/제약";
                  else if (n.includes("화학") || n.includes("에너지") || n.includes("배터리")) sector = "화학/에너지";
                  else if (n.includes("건설") || n.includes("중공업")) sector = "건설/중공업";
                  else if (n.includes("게임") || n.includes("네이버") || n.includes("카카오") || n.includes("엔터")) sector = "서비스/엔터";
                  else sector = "기타";
                }
              }
            } catch {}

            await createHolding({
              userId: ctx.user.id,
              ticker: ticker.toUpperCase(),
              name,
              quantity,
              avgPrice,
              currentPrice,
              sector: sector || "기타",
              market: marketIdx >= 0 ? row[marketIdx]?.trim() || null : null,
              currency: currencyIdx >= 0 ? row[currencyIdx]?.trim() || "KRW" : "KRW",
              dividendYield: divIdx >= 0 ? row[divIdx]?.trim() || "0" : "0",
            });

            // Auto-create initial buy transaction
            const holdingId = (await getHoldingsByUser(ctx.user.id)).find(
              (h) => h.ticker === ticker.toUpperCase()
            )?.id;
            if (holdingId) {
              await createTransaction({
                userId: ctx.user.id,
                holdingId,
                type: "buy",
                quantity,
                price: avgPrice,
                totalAmount: String(Number(quantity) * Number(avgPrice)),
                fee: "0",
                transactionDate: new Date(),
              });
            }

            imported++;
          } catch (err: any) {
            errors.push(`행 ${i + 1}: ${err.message || "알 수 없는 오류"}`);
          }
        }

        return { imported, errors };
      }),
  }),

  // ─── Portfolio Targets (Rebalancing) ─────────────────────────────
  targets: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return getTargetsByUser(ctx.user.id);
    }),

    create: protectedProcedure
      .input(
        z.object({
          targetType: z.enum(["sector", "ticker"]),
          targetKey: z.string().min(1).max(100),
          label: z.string().min(1).max(200),
          targetWeight: z.string(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const id = await createTarget({
          userId: ctx.user.id,
          targetType: input.targetType,
          targetKey: input.targetKey,
          label: input.label,
          targetWeight: input.targetWeight,
        });
        return { id };
      }),

    update: protectedProcedure
      .input(
        z.object({
          id: z.number(),
          targetKey: z.string().min(1).max(100).optional(),
          label: z.string().min(1).max(200).optional(),
          targetWeight: z.string().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const { id, ...data } = input;
        const updateData: Record<string, unknown> = {};
        if (data.targetKey !== undefined) updateData.targetKey = data.targetKey;
        if (data.label !== undefined) updateData.label = data.label;
        if (data.targetWeight !== undefined) updateData.targetWeight = data.targetWeight;
        await updateTarget(id, ctx.user.id, updateData);
        return { success: true };
      }),

    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ ctx, input }) => {
        await deleteTarget(input.id, ctx.user.id);
        return { success: true };
      }),

    // Compare current allocation vs targets
    compare: protectedProcedure.query(async ({ ctx }) => {
      const [userHoldings, userTargets] = await Promise.all([
        getHoldingsByUser(ctx.user.id),
        getTargetsByUser(ctx.user.id),
      ]);

      // Calculate current allocation
      let totalValue = 0;
      const holdingValues: { ticker: string; name: string; sector: string; value: number }[] = [];

      userHoldings.forEach((h) => {
        const qty = Number(h.quantity);
        const cur = Number(h.currentPrice) || Number(h.avgPrice);
        const val = qty * cur;
        totalValue += val;
        holdingValues.push({
          ticker: h.ticker,
          name: h.name,
          sector: h.sector || "미분류",
          value: val,
        });
      });

      // Build current weights
      const currentByTicker = new Map<string, number>();
      const currentBySector = new Map<string, number>();

      holdingValues.forEach((h) => {
        const weight = totalValue > 0 ? (h.value / totalValue) * 100 : 0;
        currentByTicker.set(h.ticker, (currentByTicker.get(h.ticker) || 0) + weight);
        currentBySector.set(h.sector, (currentBySector.get(h.sector) || 0) + weight);
      });

      // Compare with targets
      const comparison = userTargets.map((t) => {
        const currentWeight =
          t.targetType === "ticker"
            ? currentByTicker.get(t.targetKey) || 0
            : currentBySector.get(t.targetKey) || 0;
        const targetWeight = Number(t.targetWeight);
        const diff = currentWeight - targetWeight;
        const diffAmount = totalValue > 0 ? (diff / 100) * totalValue : 0;

        return {
          id: t.id,
          targetType: t.targetType,
          targetKey: t.targetKey,
          label: t.label,
          targetWeight,
          currentWeight: Math.round(currentWeight * 100) / 100,
          diff: Math.round(diff * 100) / 100,
          diffAmount: Math.round(diffAmount),
          action: diff > 1 ? "매도 검토" as const : diff < -1 ? "매수 검토" as const : "유지" as const,
        };
      });

      return { totalValue, comparison };
    }),
  }),

  // ─── Price Alerts ─────────────────────────────────────────────
  alerts: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return getAlertsByUser(ctx.user.id);
    }),

    create: protectedProcedure
      .input(
        z.object({
          holdingId: z.number().optional(),
          ticker: z.string().min(1).max(20),
          name: z.string().min(1).max(200),
          alertType: z.enum(["price_above", "price_below", "return_above", "return_below"]),
          targetValue: z.string(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const id = await createAlert({
          userId: ctx.user.id,
          holdingId: input.holdingId || null,
          ticker: input.ticker.toUpperCase(),
          name: input.name,
          alertType: input.alertType,
          targetValue: input.targetValue,
        });
        return { id };
      }),

    update: protectedProcedure
      .input(
        z.object({
          id: z.number(),
          status: z.enum(["active", "paused"]).optional(),
          targetValue: z.string().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const { id, ...data } = input;
        const updateData: Record<string, unknown> = {};
        if (data.status !== undefined) updateData.status = data.status;
        if (data.targetValue !== undefined) updateData.targetValue = data.targetValue;
        await updateAlert(id, ctx.user.id, updateData);
        return { success: true };
      }),

    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ ctx, input }) => {
        await deleteAlert(input.id, ctx.user.id);
        return { success: true };
      }),

    // Check alerts against current prices
    check: protectedProcedure.mutation(async ({ ctx }) => {
      const activeAlerts = await getActiveAlerts(ctx.user.id);
      if (activeAlerts.length === 0) return { checked: 0, triggered: [] };

      const userHoldings = await getHoldingsByUser(ctx.user.id);
      const holdingMap = new Map(userHoldings.map((h) => [h.ticker, h]));

      const triggered: { id: number; ticker: string; alertType: string; targetValue: string; currentValue: number }[] = [];

      for (const alert of activeAlerts) {
        const holding = holdingMap.get(alert.ticker);
        if (!holding) continue;

        const currentPrice = Number(holding.currentPrice) || Number(holding.avgPrice);
        const avgPrice = Number(holding.avgPrice);
        const returnRate = avgPrice > 0 ? ((currentPrice - avgPrice) / avgPrice) * 100 : 0;

        let isTriggered = false;
        let currentValue = 0;

        switch (alert.alertType) {
          case "price_above":
            currentValue = currentPrice;
            isTriggered = currentPrice >= Number(alert.targetValue);
            break;
          case "price_below":
            currentValue = currentPrice;
            isTriggered = currentPrice <= Number(alert.targetValue);
            break;
          case "return_above":
            currentValue = returnRate;
            isTriggered = returnRate >= Number(alert.targetValue);
            break;
          case "return_below":
            currentValue = returnRate;
            isTriggered = returnRate <= Number(alert.targetValue);
            break;
        }

        if (isTriggered) {
          await updateAlert(alert.id, ctx.user.id, {
            triggered: "yes",
            triggeredAt: new Date(),
          });
          triggered.push({
            id: alert.id,
            ticker: alert.ticker,
            alertType: alert.alertType,
            targetValue: alert.targetValue,
            currentValue,
          });

          // Send notification
          const alertTypeLabels: Record<string, string> = {
            price_above: "목표가 도달 (상향)",
            price_below: "목표가 도달 (하향)",
            return_above: "수익률 도달 (상향)",
            return_below: "수익률 도달 (하향)",
          };
          try {
            await notifyOwner({
              title: `[${alert.ticker}] ${alertTypeLabels[alert.alertType]}`,
              content: `${alert.name} (${alert.ticker})의 ${alertTypeLabels[alert.alertType]} 알림이 발동되었습니다. 현재값: ${currentValue.toFixed(2)}, 목표값: ${alert.targetValue}`,
            });
          } catch {}
        }
      }

      return { checked: activeAlerts.length, triggered };
    }),

    // Reset a triggered alert back to active
    reset: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ ctx, input }) => {
        await updateAlert(input.id, ctx.user.id, {
          triggered: "no",
          triggeredAt: null,
        });
        return { success: true };
      }),
  }),
});

// CSV row parser that handles quoted fields
function parseCSVRow(row: string): string[] {
  const result: string[] = [];
  let current = "";
  let inQuotes = false;

  for (let i = 0; i < row.length; i++) {
    const char = row[i];
    if (inQuotes) {
      if (char === '"' && row[i + 1] === '"') {
        current += '"';
        i++;
      } else if (char === '"') {
        inQuotes = false;
      } else {
        current += char;
      }
    } else {
      if (char === '"') {
        inQuotes = true;
      } else if (char === ",") {
        result.push(current);
        current = "";
      } else {
        current += char;
      }
    }
  }
  result.push(current);
  return result;
}

export type AppRouter = typeof appRouter;
