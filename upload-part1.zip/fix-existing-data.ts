import { getHoldingsByUser, updateHolding, getDb } from "./server/db";
import { callDataApi } from "./server/_core/dataApi";
import { eq } from "drizzle-orm";
import { holdings } from "./drizzle/schema";

const priceCache = new Map<string, number>();

async function fetchStockPrice(ticker: string) {
  if (priceCache.has(ticker)) return priceCache.get(ticker);

  const symbolsToTry = [ticker.toUpperCase()];
  if (/^\d{6}$/.test(ticker)) {
    symbolsToTry.push(`${ticker}.KS`, `${ticker}.KQ`);
  }

  for (const symbol of symbolsToTry) {
    try {
      const result = await callDataApi("YahooFinance/get_stock_chart", {
        query: {
          symbol: symbol,
          interval: "1d",
          range: "5d",
          includeAdjustedClose: true,
        },
      }) as any;

      if (result?.chart?.result?.[0]) {
        const price = result.chart.result[0].meta.regularMarketPrice ?? 0;
        if (price > 0) {
          priceCache.set(ticker, price);
          return price;
        }
      }
    } catch (err) {
      console.warn(`[StockPrice] Failed to fetch ${symbol}:`, err);
    }
  }
  return null;
}

function guessSector(name: string) {
  const n = name.toLowerCase();
  if (n.includes("전자") || n.includes("반도체") || n.includes("하이닉스")) return "IT/반도체";
  if (n.includes("은행") || n.includes("금융") || n.includes("증권") || n.includes("생명") || n.includes("화재")) return "금융";
  if (n.includes("자동차") || n.includes("모빌리티") || n.includes("현대차") || n.includes("기아")) return "자동차";
  if (n.includes("바이오") || n.includes("제약") || n.includes("셀트리온")) return "바이오/제약";
  if (n.includes("화학") || n.includes("에너지") || n.includes("배터리")) return "화학/에너지";
  if (n.includes("건설") || n.includes("중공업")) return "건설/중공업";
  if (n.includes("게임") || n.includes("네이버") || n.includes("카카오") || n.includes("엔터")) return "서비스/엔터";
  return "기타";
}

async function run() {
  const db = await getDb();
  if (!db) {
    console.error("Database not connected");
    return;
  }

  const allHoldings = await db.select().from(holdings);
  console.log(`Found ${allHoldings.length} holdings to process`);

  for (const h of allHoldings) {
    const updates: any = {};
    
    // Update sector if missing
    if (!h.sector || h.sector === "미분류" || h.sector === "기타") {
      const newSector = guessSector(h.name);
      if (newSector !== h.sector) {
        updates.sector = newSector;
      }
    }

    // Update current price
    const price = await fetchStockPrice(h.ticker);
    if (price && price > 0) {
      updates.currentPrice = String(price);
    }

    if (Object.keys(updates).length > 0) {
      console.log(`Updating ${h.ticker} (${h.name}):`, updates);
      await db.update(holdings).set(updates).where(eq(holdings.id, h.id));
    }
  }

  console.log("Data fix completed");
  process.exit(0);
}

run().catch(console.error);
