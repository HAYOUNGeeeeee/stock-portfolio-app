import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import {
  TrendingUp,
  TrendingDown,
  DollarSign,
  BarChart3,
  Briefcase,
  Activity,
  RefreshCw,
  Zap,
} from "lucide-react";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts";
import { useMemo, useState } from "react";
import { useLocation } from "wouter";
import { toast } from "sonner";

function formatCurrency(value: number, currency = "KRW") {
  if (currency === "USD") {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      maximumFractionDigits: 2,
    }).format(value);
  }
  return new Intl.NumberFormat("ko-KR", {
    style: "currency",
    currency: "KRW",
    maximumFractionDigits: 0,
  }).format(value);
}

function formatPercent(value: number) {
  return `${value >= 0 ? "+" : ""}${value.toFixed(2)}%`;
}

const CHART_COLORS = [
  "oklch(0.65 0.15 250)",
  "oklch(0.7 0.12 200)",
  "oklch(0.75 0.15 155)",
  "oklch(0.75 0.15 75)",
  "oklch(0.65 0.18 320)",
  "oklch(0.6 0.15 280)",
  "oklch(0.7 0.15 130)",
  "oklch(0.65 0.12 30)",
];

export default function Home() {
  const [, setLocation] = useLocation();
  const { data: summary, isLoading: summaryLoading } =
    trpc.portfolio.summary.useQuery();
  const { data: holdings, isLoading: holdingsLoading } =
    trpc.holdings.list.useQuery();
  const { data: snapshots, isLoading: snapshotsLoading } =
    trpc.portfolio.snapshots.useQuery({ limit: 90 });

  // Fetch real-time prices for all holdings
  const tickers = useMemo(() => {
    return holdings?.map((h) => h.ticker) || [];
  }, [holdings]);

  const { data: livePrices, isLoading: pricesLoading } =
    trpc.stock.getPrices.useQuery(
      { tickers },
      { enabled: tickers.length > 0, refetchInterval: 5 * 60 * 1000 }
    );

  const utils = trpc.useUtils();
  const refreshMutation = trpc.stock.refreshAll.useMutation({
    onSuccess: (data) => {
      utils.holdings.list.invalidate();
      utils.portfolio.summary.invalidate();
      toast.success(`${data.count}개 종목의 가격이 업데이트되었습니다`);
    },
    onError: () => toast.error("가격 업데이트에 실패했습니다"),
  });

  // Calculate real-time portfolio values
  const realTimeData = useMemo(() => {
    if (!holdings || holdings.length === 0) {
      return {
        totalInvested: summary?.totalInvested || 0,
        totalValue: summary?.totalValue || 0,
        totalReturn: summary?.totalReturn || 0,
        returnRate: summary?.returnRate || 0,
        holdingsCount: summary?.holdingsCount || 0,
      };
    }

    let totalInvested = 0;
    let totalValue = 0;

    holdings.forEach((h) => {
      const qty = Number(h.quantity);
      const avg = Number(h.avgPrice);
      const livePrice = livePrices?.[h.ticker]?.price;
      const cur = livePrice || Number(h.currentPrice) || avg;

      totalInvested += qty * avg;
      totalValue += qty * cur;
    });

    const totalReturn = totalValue - totalInvested;
    const returnRate = totalInvested > 0 ? (totalReturn / totalInvested) * 100 : 0;

    return {
      totalInvested,
      totalValue,
      totalReturn,
      returnRate,
      holdingsCount: holdings.length,
    };
  }, [holdings, livePrices, summary]);

  const pieData = useMemo(() => {
    if (!holdings || holdings.length === 0) return [];
    return holdings.map((h) => {
      const livePrice = livePrices?.[h.ticker]?.price;
      const cur = livePrice || Number(h.currentPrice) || Number(h.avgPrice);
      return {
        name: h.name,
        value: Number(h.quantity) * cur,
        ticker: h.ticker,
      };
    });
  }, [holdings, livePrices]);

  const chartData = useMemo(() => {
    if (!snapshots || snapshots.length === 0) return [];
    return snapshots.map((s) => ({
      date: new Date(s.snapshotDate).toLocaleDateString("ko-KR", {
        month: "short",
        day: "numeric",
      }),
      value: Number(s.totalValue),
      invested: Number(s.totalInvested),
      returnRate: Number(s.returnRate),
    }));
  }, [snapshots]);

  const isLoading = summaryLoading || holdingsLoading;
  const hasLivePrices = livePrices && Object.keys(livePrices).length > 0;

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">대시보드</h1>
          <p className="text-muted-foreground text-sm mt-1">
            포트폴리오 현황을 한눈에 확인하세요
            {hasLivePrices && (
              <span className="inline-flex items-center gap-1 ml-2 text-primary">
                <Zap className="h-3 w-3" />
                <span className="text-xs">실시간</span>
              </span>
            )}
          </p>
        </div>
        <Button
          variant="outline"
          size="sm"
          className="gap-2 bg-transparent"
          onClick={() => refreshMutation.mutate()}
          disabled={refreshMutation.isPending || !holdings || holdings.length === 0}
        >
          <RefreshCw className={`h-4 w-4 ${refreshMutation.isPending ? "animate-spin" : ""}`} />
          {refreshMutation.isPending ? "업데이트 중..." : "가격 새로고침"}
        </Button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <SummaryCard
          title="총 투자금액"
          value={formatCurrency(realTimeData.totalInvested)}
          icon={DollarSign}
          loading={isLoading}
          subtitle="원금 합계"
        />
        <SummaryCard
          title="현재 평가액"
          value={formatCurrency(realTimeData.totalValue)}
          icon={BarChart3}
          loading={isLoading}
          subtitle={hasLivePrices ? "실시간 반영" : "마지막 업데이트 기준"}
          highlight={hasLivePrices}
        />
        <SummaryCard
          title="총 수익"
          value={formatCurrency(realTimeData.totalReturn)}
          icon={
            realTimeData.totalReturn >= 0 ? TrendingUp : TrendingDown
          }
          loading={isLoading}
          trend={realTimeData.totalReturn}
          subtitle={formatPercent(realTimeData.returnRate)}
        />
        <SummaryCard
          title="보유 종목"
          value={`${realTimeData.holdingsCount}개`}
          icon={Briefcase}
          loading={isLoading}
          subtitle="종목 수"
        />
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Performance Chart */}
        <Card className="lg:col-span-2 bg-card border-border">
          <CardHeader className="pb-2">
            <CardTitle className="text-base font-semibold flex items-center gap-2">
              <Activity className="h-4 w-4 text-primary" />
              포트폴리오 성과 추이
            </CardTitle>
          </CardHeader>
          <CardContent>
            {snapshotsLoading ? (
              <Skeleton className="h-[280px] w-full" />
            ) : chartData.length > 0 ? (
              <ResponsiveContainer width="100%" height={280}>
                <AreaChart data={chartData}>
                  <defs>
                    <linearGradient
                      id="colorValue"
                      x1="0"
                      y1="0"
                      x2="0"
                      y2="1"
                    >
                      <stop
                        offset="5%"
                        stopColor="oklch(0.65 0.15 250)"
                        stopOpacity={0.3}
                      />
                      <stop
                        offset="95%"
                        stopColor="oklch(0.65 0.15 250)"
                        stopOpacity={0}
                      />
                    </linearGradient>
                    <linearGradient
                      id="colorInvested"
                      x1="0"
                      y1="0"
                      x2="0"
                      y2="1"
                    >
                      <stop
                        offset="5%"
                        stopColor="oklch(0.6 0.015 260)"
                        stopOpacity={0.2}
                      />
                      <stop
                        offset="95%"
                        stopColor="oklch(0.6 0.015 260)"
                        stopOpacity={0}
                      />
                    </linearGradient>
                  </defs>
                  <CartesianGrid
                    strokeDasharray="3 3"
                    stroke="oklch(0.28 0.015 260)"
                    vertical={false}
                  />
                  <XAxis
                    dataKey="date"
                    stroke="oklch(0.5 0.015 260)"
                    fontSize={11}
                    tickLine={false}
                    axisLine={false}
                  />
                  <YAxis
                    stroke="oklch(0.5 0.015 260)"
                    fontSize={11}
                    tickLine={false}
                    axisLine={false}
                    tickFormatter={(v) =>
                      `${(v / 10000).toFixed(0)}만`
                    }
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "oklch(0.19 0.015 260)",
                      border: "1px solid oklch(0.28 0.015 260)",
                      borderRadius: "8px",
                      fontSize: "12px",
                      color: "oklch(0.93 0.005 250)",
                    }}
                    formatter={(value: number, name: string) => [
                      formatCurrency(value),
                      name === "value" ? "평가액" : "투자금",
                    ]}
                  />
                  <Area
                    type="monotone"
                    dataKey="invested"
                    stroke="oklch(0.5 0.015 260)"
                    strokeWidth={1.5}
                    strokeDasharray="4 4"
                    fill="url(#colorInvested)"
                  />
                  <Area
                    type="monotone"
                    dataKey="value"
                    stroke="oklch(0.65 0.15 250)"
                    strokeWidth={2}
                    fill="url(#colorValue)"
                  />
                </AreaChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-[280px] flex items-center justify-center text-muted-foreground text-sm">
                <div className="text-center">
                  <Activity className="h-10 w-10 mx-auto mb-3 opacity-30" />
                  <p>아직 성과 데이터가 없습니다</p>
                  <p className="text-xs mt-1">종목을 추가하면 성과 추이가 기록됩니다</p>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Portfolio Allocation Pie Chart */}
        <Card className="bg-card border-border">
          <CardHeader className="pb-2">
            <CardTitle className="text-base font-semibold flex items-center gap-2">
              <Briefcase className="h-4 w-4 text-primary" />
              자산 배분
            </CardTitle>
          </CardHeader>
          <CardContent>
            {holdingsLoading ? (
              <Skeleton className="h-[280px] w-full" />
            ) : pieData.length > 0 ? (
              <div className="h-[280px] flex flex-col items-center justify-center">
                <ResponsiveContainer width="100%" height={200}>
                  <PieChart>
                    <Pie
                      data={pieData}
                      cx="50%"
                      cy="50%"
                      innerRadius={55}
                      outerRadius={80}
                      paddingAngle={3}
                      dataKey="value"
                      strokeWidth={0}
                    >
                      {pieData.map((_, index) => (
                        <Cell
                          key={`cell-${index}`}
                          fill={CHART_COLORS[index % CHART_COLORS.length]}
                        />
                      ))}
                    </Pie>
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "oklch(0.19 0.015 260)",
                        border: "1px solid oklch(0.28 0.015 260)",
                        borderRadius: "8px",
                        fontSize: "12px",
                        color: "oklch(0.93 0.005 250)",
                      }}
                      formatter={(value: number) => [formatCurrency(value), "평가액"]}
                    />
                  </PieChart>
                </ResponsiveContainer>
                <div className="flex flex-wrap gap-x-4 gap-y-1 justify-center mt-2">
                  {pieData.slice(0, 5).map((item, index) => (
                    <div
                      key={item.ticker}
                      className="flex items-center gap-1.5 text-xs"
                    >
                      <div
                        className="w-2.5 h-2.5 rounded-full shrink-0"
                        style={{
                          backgroundColor:
                            CHART_COLORS[index % CHART_COLORS.length],
                        }}
                      />
                      <span className="text-muted-foreground">{item.ticker}</span>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="h-[280px] flex items-center justify-center text-muted-foreground text-sm">
                <div className="text-center">
                  <Briefcase className="h-10 w-10 mx-auto mb-3 opacity-30" />
                  <p>보유 종목이 없습니다</p>
                  <p className="text-xs mt-1">종목을 추가하여 시작하세요</p>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Holdings Quick View with Real-time Prices */}
      {holdings && holdings.length > 0 && (
        <Card className="bg-card border-border">
          <CardHeader className="pb-2 flex flex-row items-center justify-between">
            <CardTitle className="text-base font-semibold">
              보유 종목 현황
              {pricesLoading && (
                <span className="ml-2 text-xs text-muted-foreground font-normal">가격 로딩 중...</span>
              )}
            </CardTitle>
            <Button
              variant="ghost"
              size="sm"
              className="text-xs text-muted-foreground hover:text-foreground"
              onClick={() => setLocation("/holdings")}
            >
              전체 보기
            </Button>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border">
                    <th className="text-left py-3 px-2 text-muted-foreground font-medium text-xs uppercase tracking-wider">
                      종목
                    </th>
                    <th className="text-right py-3 px-2 text-muted-foreground font-medium text-xs uppercase tracking-wider">
                      수량
                    </th>
                    <th className="text-right py-3 px-2 text-muted-foreground font-medium text-xs uppercase tracking-wider hidden sm:table-cell">
                      평균매수가
                    </th>
                    <th className="text-right py-3 px-2 text-muted-foreground font-medium text-xs uppercase tracking-wider">
                      현재가
                    </th>
                    <th className="text-right py-3 px-2 text-muted-foreground font-medium text-xs uppercase tracking-wider hidden sm:table-cell">
                      평가금액
                    </th>
                    <th className="text-right py-3 px-2 text-muted-foreground font-medium text-xs uppercase tracking-wider">
                      수익률
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {holdings.slice(0, 5).map((h) => {
                    const avg = Number(h.avgPrice);
                    const livePrice = livePrices?.[h.ticker]?.price;
                    const cur = livePrice || Number(h.currentPrice) || avg;
                    const qty = Number(h.quantity);
                    const totalValue = qty * cur;
                    const returnRate = avg > 0 ? ((cur - avg) / avg) * 100 : 0;
                    const isGain = returnRate >= 0;
                    const priceChange = livePrices?.[h.ticker]?.changePercent;

                    return (
                      <tr
                        key={h.id}
                        className="border-b border-border/50 hover:bg-accent/30 transition-colors cursor-pointer"
                        onClick={() => setLocation(`/holdings/${h.id}`)}
                      >
                        <td className="py-3 px-2">
                          <div>
                            <span className="font-medium">{h.ticker}</span>
                            <span className="text-muted-foreground text-xs ml-2 hidden sm:inline">
                              {h.name}
                            </span>
                          </div>
                        </td>
                        <td className="py-3 px-2 text-right tabular-nums">
                          {qty.toLocaleString()}
                        </td>
                        <td className="py-3 px-2 text-right tabular-nums hidden sm:table-cell">
                          {formatCurrency(avg)}
                        </td>
                        <td className="py-3 px-2 text-right">
                          <div className="tabular-nums">{formatCurrency(cur)}</div>
                          {priceChange !== undefined && priceChange !== null && (
                            <div className={`text-xs tabular-nums ${priceChange >= 0 ? "text-gain" : "text-loss"}`}>
                              {priceChange >= 0 ? "+" : ""}{priceChange.toFixed(2)}%
                            </div>
                          )}
                        </td>
                        <td className="py-3 px-2 text-right tabular-nums hidden sm:table-cell">
                          {formatCurrency(totalValue)}
                        </td>
                        <td className="py-3 px-2 text-right">
                          <span
                            className={`inline-flex items-center gap-1 text-xs font-medium px-2 py-0.5 rounded-full ${
                              isGain
                                ? "text-gain bg-gain"
                                : "text-loss bg-loss"
                            }`}
                          >
                            {isGain ? (
                              <TrendingUp className="h-3 w-3" />
                            ) : (
                              <TrendingDown className="h-3 w-3" />
                            )}
                            {formatPercent(returnRate)}
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

function SummaryCard({
  title,
  value,
  icon: Icon,
  loading,
  trend,
  subtitle,
  highlight,
}: {
  title: string;
  value: string;
  icon: React.ComponentType<{ className?: string }>;
  loading?: boolean;
  trend?: number;
  subtitle?: string;
  highlight?: boolean;
}) {
  const isGain = trend !== undefined && trend >= 0;
  const isLoss = trend !== undefined && trend < 0;

  return (
    <Card className={`bg-card border-border card-hover ${highlight ? "glow-primary" : ""}`}>
      <CardContent className="p-5">
        {loading ? (
          <div className="space-y-3">
            <Skeleton className="h-4 w-24" />
            <Skeleton className="h-8 w-32" />
            <Skeleton className="h-3 w-16" />
          </div>
        ) : (
          <>
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
                {title}
              </span>
              <div className="h-8 w-8 rounded-lg bg-primary/10 flex items-center justify-center">
                <Icon className="h-4 w-4 text-primary" />
              </div>
            </div>
            <div
              className={`text-xl font-bold tabular-nums ${
                isGain ? "text-gain" : isLoss ? "text-loss" : ""
              }`}
            >
              {value}
            </div>
            {subtitle && (
              <p
                className={`text-xs mt-1 ${
                  isGain
                    ? "text-gain"
                    : isLoss
                      ? "text-loss"
                      : "text-muted-foreground"
                }`}
              >
                {subtitle}
              </p>
            )}
          </>
        )}
      </CardContent>
    </Card>
  );
}
