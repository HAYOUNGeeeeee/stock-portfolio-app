import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import {
  BarChart3,
  TrendingUp,
  TrendingDown,
  PieChart as PieChartIcon,
  Save,
} from "lucide-react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
  Legend,
} from "recharts";
import { useMemo } from "react";
import { toast } from "sonner";

function formatCurrency(value: number) {
  return new Intl.NumberFormat("ko-KR", {
    style: "currency",
    currency: "KRW",
    maximumFractionDigits: 0,
  }).format(value);
}

function formatPercent(value: number) {
  return `${value >= 0 ? "+" : ""}${value.toFixed(2)}%`;
}

const CHART_COLORS = [
  "oklch(0.65 0.15 250)",
  "oklch(0.7 0.12 200)",
  "oklch(0.75 0.15 155)",
  "oklch(0.75 0.15 75)",
  "oklch(0.65 0.18 320)",
  "oklch(0.6 0.15 280)",
  "oklch(0.7 0.15 130)",
  "oklch(0.65 0.12 30)",
];

export default function Analysis() {
  const { data: holdings, isLoading: holdingsLoading } =
    trpc.holdings.list.useQuery();
  const { data: snapshots, isLoading: snapshotsLoading } =
    trpc.portfolio.snapshots.useQuery({ limit: 365 });
  const { data: summary } = trpc.portfolio.summary.useQuery();
  const utils = trpc.useUtils();

  const saveSnapshotMutation = trpc.portfolio.saveSnapshot.useMutation({
    onSuccess: () => {
      utils.portfolio.snapshots.invalidate();
      toast.success("포트폴리오 스냅샷이 저장되었습니다");
    },
    onError: (err) => toast.error(err.message),
  });

  // Sector allocation data
  const sectorData = useMemo(() => {
    if (!holdings) return [];
    const sectors: Record<string, number> = {};
    holdings.forEach((h) => {
      const sector = h.sector || "기타";
      const value =
        Number(h.quantity) * (Number(h.currentPrice) || Number(h.avgPrice));
      sectors[sector] = (sectors[sector] || 0) + value;
    });
    return Object.entries(sectors)
      .map(([name, value]) => ({ name, value }))
      .sort((a, b) => b.value - a.value);
  }, [holdings]);

  // Per-holding return data for bar chart
  const returnData = useMemo(() => {
    if (!holdings) return [];
    return holdings
      .map((h) => {
        const avg = Number(h.avgPrice);
        const cur = Number(h.currentPrice) || avg;
        const returnRate = avg > 0 ? ((cur - avg) / avg) * 100 : 0;
        return {
          name: h.ticker,
          fullName: h.name,
          returnRate: Number(returnRate.toFixed(2)),
          value:
            Number(h.quantity) * cur - Number(h.quantity) * avg,
        };
      })
      .sort((a, b) => b.returnRate - a.returnRate);
  }, [holdings]);

  // Snapshot line chart data
  const snapshotChartData = useMemo(() => {
    if (!snapshots || snapshots.length === 0) return [];
    return snapshots.map((s) => ({
      date: new Date(s.snapshotDate).toLocaleDateString("ko-KR", {
        month: "short",
        day: "numeric",
      }),
      returnRate: Number(Number(s.returnRate).toFixed(2)),
      totalValue: Number(s.totalValue),
      totalInvested: Number(s.totalInvested),
    }));
  }, [snapshots]);

  // Dividend summary
  const dividendSummary = useMemo(() => {
    if (!holdings) return { totalYield: 0, estimatedAnnual: 0 };
    let totalValue = 0;
    let weightedYield = 0;
    holdings.forEach((h) => {
      const value =
        Number(h.quantity) * (Number(h.currentPrice) || Number(h.avgPrice));
      totalValue += value;
      weightedYield += value * Number(h.dividendYield || 0);
    });
    const avgYield = totalValue > 0 ? weightedYield / totalValue : 0;
    return {
      totalYield: isNaN(avgYield) ? 0 : avgYield,
      estimatedAnnual: isNaN(totalValue * avgYield) ? 0 : (totalValue * avgYield) / 100,
    };
  }, [holdings]);

  const isLoading = holdingsLoading || snapshotsLoading;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">포트폴리오 분석</h1>
          <p className="text-muted-foreground text-sm mt-1">
            투자 성과와 자산 배분을 분석합니다
          </p>
        </div>
        <Button
          variant="outline"
          className="gap-2 bg-transparent"
          onClick={() => saveSnapshotMutation.mutate()}
          disabled={saveSnapshotMutation.isPending}
        >
          <Save className="h-4 w-4" />
          스냅샷 저장
        </Button>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Card className="bg-card border-border">
          <CardContent className="p-5">
            <div className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-2">
              총 수익률
            </div>
            <div
              className={`text-2xl font-bold tabular-nums ${
                summary && summary.returnRate >= 0
                  ? "text-gain"
                  : "text-loss"
              }`}
            >
              {summary ? formatPercent(summary.returnRate) : "-"}
            </div>
          </CardContent>
        </Card>
        <Card className="bg-card border-border">
          <CardContent className="p-5">
            <div className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-2">
              평균 배당수익률
            </div>
            <div className="text-2xl font-bold tabular-nums text-primary">
              {dividendSummary.totalYield.toFixed(2)}%
            </div>
          </CardContent>
        </Card>
        <Card className="bg-card border-border">
          <CardContent className="p-5">
            <div className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-2">
              예상 연간 배당금
            </div>
            <div className="text-2xl font-bold tabular-nums">
              {formatCurrency(dividendSummary.estimatedAnnual)}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Return Rate by Holding */}
        <Card className="bg-card border-border">
          <CardHeader className="pb-2">
            <CardTitle className="text-base font-semibold flex items-center gap-2">
              <BarChart3 className="h-4 w-4 text-primary" />
              종목별 수익률
            </CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <Skeleton className="h-[300px] w-full" />
            ) : returnData.length > 0 ? (
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={returnData} layout="vertical">
                  <CartesianGrid
                    strokeDasharray="3 3"
                    stroke="oklch(0.28 0.015 260)"
                    horizontal={false}
                  />
                  <XAxis
                    type="number"
                    stroke="oklch(0.5 0.015 260)"
                    fontSize={11}
                    tickLine={false}
                    axisLine={false}
                    tickFormatter={(v) => `${v}%`}
                  />
                  <YAxis
                    type="category"
                    dataKey="name"
                    stroke="oklch(0.5 0.015 260)"
                    fontSize={11}
                    tickLine={false}
                    axisLine={false}
                    width={60}
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "oklch(0.19 0.015 260)",
                      border: "1px solid oklch(0.28 0.015 260)",
                      borderRadius: "8px",
                      fontSize: "12px",
                      color: "oklch(0.93 0.005 250)",
                    }}
                    formatter={(value: number) => [
                      `${value.toFixed(2)}%`,
                      "수익률",
                    ]}
                  />
                  <Bar
                    dataKey="returnRate"
                    radius={[0, 4, 4, 0]}
                    fill="oklch(0.65 0.15 250)"
                  >
                    {returnData.map((entry, index) => (
                      <Cell
                        key={`cell-${index}`}
                        fill={
                          entry.returnRate >= 0
                            ? "oklch(0.72 0.19 155)"
                            : "oklch(0.65 0.2 25)"
                        }
                      />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-[300px] flex items-center justify-center text-muted-foreground text-sm">
                <div className="text-center">
                  <BarChart3 className="h-10 w-10 mx-auto mb-3 opacity-30" />
                  <p>분석할 종목이 없습니다</p>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Sector Allocation */}
        <Card className="bg-card border-border">
          <CardHeader className="pb-2">
            <CardTitle className="text-base font-semibold flex items-center gap-2">
              <PieChartIcon className="h-4 w-4 text-primary" />
              섹터별 배분
            </CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <Skeleton className="h-[300px] w-full" />
            ) : sectorData.length > 0 ? (
              <div className="h-[300px] flex flex-col items-center justify-center">
                <ResponsiveContainer width="100%" height={220}>
                  <PieChart>
                    <Pie
                      data={sectorData}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={90}
                      paddingAngle={3}
                      dataKey="value"
                      strokeWidth={0}
                    >
                      {sectorData.map((_, index) => (
                        <Cell
                          key={`cell-${index}`}
                          fill={CHART_COLORS[index % CHART_COLORS.length]}
                        />
                      ))}
                    </Pie>
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "oklch(0.19 0.015 260)",
                        border: "1px solid oklch(0.28 0.015 260)",
                        borderRadius: "8px",
                        fontSize: "12px",
                        color: "oklch(0.93 0.005 250)",
                      }}
                      formatter={(value: number) => [
                        formatCurrency(value),
                        "평가액",
                      ]}
                    />
                  </PieChart>
                </ResponsiveContainer>
                <div className="flex flex-wrap gap-x-4 gap-y-1 justify-center">
                  {sectorData.map((item, index) => (
                    <div
                      key={item.name}
                      className="flex items-center gap-1.5 text-xs"
                    >
                      <div
                        className="w-2.5 h-2.5 rounded-full shrink-0"
                        style={{
                          backgroundColor:
                            CHART_COLORS[index % CHART_COLORS.length],
                        }}
                      />
                      <span className="text-muted-foreground">{item.name}</span>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="h-[300px] flex items-center justify-center text-muted-foreground text-sm">
                <div className="text-center">
                  <PieChartIcon className="h-10 w-10 mx-auto mb-3 opacity-30" />
                  <p>분석할 데이터가 없습니다</p>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Performance Over Time */}
      <Card className="bg-card border-border">
        <CardHeader className="pb-2">
          <CardTitle className="text-base font-semibold flex items-center gap-2">
            <TrendingUp className="h-4 w-4 text-primary" />
            수익률 추이
          </CardTitle>
        </CardHeader>
        <CardContent>
          {snapshotsLoading ? (
            <Skeleton className="h-[300px] w-full" />
          ) : snapshotChartData.length > 0 ? (
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={snapshotChartData}>
                <CartesianGrid
                  strokeDasharray="3 3"
                  stroke="oklch(0.28 0.015 260)"
                  vertical={false}
                />
                <XAxis
                  dataKey="date"
                  stroke="oklch(0.5 0.015 260)"
                  fontSize={11}
                  tickLine={false}
                  axisLine={false}
                />
                <YAxis
                  stroke="oklch(0.5 0.015 260)"
                  fontSize={11}
                  tickLine={false}
                  axisLine={false}
                  tickFormatter={(v) => `${v}%`}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "oklch(0.19 0.015 260)",
                    border: "1px solid oklch(0.28 0.015 260)",
                    borderRadius: "8px",
                    fontSize: "12px",
                    color: "oklch(0.93 0.005 250)",
                  }}
                  formatter={(value: number) => [
                    `${value.toFixed(2)}%`,
                    "수익률",
                  ]}
                />
                <Line
                  type="monotone"
                  dataKey="returnRate"
                  stroke="oklch(0.65 0.15 250)"
                  strokeWidth={2}
                  dot={false}
                  activeDot={{ r: 4, fill: "oklch(0.65 0.15 250)" }}
                />
              </LineChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-[300px] flex items-center justify-center text-muted-foreground text-sm">
              <div className="text-center">
                <TrendingUp className="h-10 w-10 mx-auto mb-3 opacity-30" />
                <p>수익률 추이 데이터가 없습니다</p>
                <p className="text-xs mt-1">
                  "스냅샷 저장" 버튼을 눌러 현재 상태를 기록하세요
                </p>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
