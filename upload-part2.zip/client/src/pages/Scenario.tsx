import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import {
  Target,
  TrendingUp,
  TrendingDown,
  Minus,
  Briefcase,
  DollarSign,
  BarChart3,
} from "lucide-react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
  BarChart,
  Bar,
  Cell,
} from "recharts";
import { useMemo } from "react";

function formatCurrency(value: number, currency = "KRW") {
  if (currency === "USD") {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      maximumFractionDigits: 2,
    }).format(value);
  }
  return new Intl.NumberFormat("ko-KR", {
    style: "currency",
    currency: "KRW",
    maximumFractionDigits: 0,
  }).format(value);
}

function formatPercent(value: number) {
  return `${value >= 0 ? "+" : ""}${value.toFixed(2)}%`;
}

export default function Scenario() {
  const { data: holdings, isLoading: holdingsLoading } = trpc.holdings.list.useQuery();
  const { data: summary } = trpc.portfolio.summary.useQuery();

  // Get tickers for batch price fetch
  const tickers = useMemo(() => {
    return holdings?.map((h) => h.ticker) || [];
  }, [holdings]);

  const { data: prices, isLoading: pricesLoading } = trpc.stock.getPrices.useQuery(
    { tickers },
    { enabled: tickers.length > 0 }
  );

  // Fetch scenario for each holding
  const holdingsWithPrices = useMemo(() => {
    if (!holdings) return [];
    return holdings.map((h) => {
      const livePrice = prices?.[h.ticker]?.price;
      const currentPrice = livePrice || Number(h.currentPrice) || Number(h.avgPrice);
      return { ...h, realTimePrice: currentPrice };
    });
  }, [holdings, prices]);

  const isLoading = holdingsLoading || pricesLoading;

  // Portfolio-level scenario (aggregate)
  const portfolioScenario = useMemo(() => {
    if (!holdingsWithPrices || holdingsWithPrices.length === 0) return null;

    let totalCurrentValue = 0;
    let totalInvested = 0;

    holdingsWithPrices.forEach((h) => {
      const qty = Number(h.quantity);
      totalCurrentValue += qty * h.realTimePrice;
      totalInvested += qty * Number(h.avgPrice);
    });

    // Simple portfolio-level projection using weighted average returns
    // Conservative estimates: 5% neutral, 12% optimistic, -3% pessimistic annual
    const years = [1, 2, 3, 4, 5];
    const scenarios = {
      optimistic: years.map((y) => ({
        year: y,
        value: Math.round(totalCurrentValue * Math.pow(1.12, y)),
        invested: totalInvested,
      })),
      neutral: years.map((y) => ({
        year: y,
        value: Math.round(totalCurrentValue * Math.pow(1.05, y)),
        invested: totalInvested,
      })),
      pessimistic: years.map((y) => ({
        year: y,
        value: Math.round(totalCurrentValue * Math.pow(0.97, y)),
        invested: totalInvested,
      })),
    };

    return { totalCurrentValue, totalInvested, scenarios };
  }, [holdingsWithPrices]);

  const portfolioChartData = useMemo(() => {
    if (!portfolioScenario) return [];
    return [
      {
        year: "현재",
        낙관: portfolioScenario.totalCurrentValue,
        중립: portfolioScenario.totalCurrentValue,
        비관: portfolioScenario.totalCurrentValue,
        투자원금: portfolioScenario.totalInvested,
      },
      ...portfolioScenario.scenarios.optimistic.map((_, i) => ({
        year: `${i + 1}년 후`,
        낙관: portfolioScenario.scenarios.optimistic[i].value,
        중립: portfolioScenario.scenarios.neutral[i].value,
        비관: portfolioScenario.scenarios.pessimistic[i].value,
        투자원금: portfolioScenario.totalInvested,
      })),
    ];
  }, [portfolioScenario]);

  // Per-holding 5-year projection comparison
  const holdingProjections = useMemo(() => {
    if (!holdingsWithPrices) return [];
    return holdingsWithPrices.map((h) => {
      const qty = Number(h.quantity);
      const currentValue = qty * h.realTimePrice;
      const invested = qty * Number(h.avgPrice);
      const neutral5y = currentValue * Math.pow(1.05, 5);
      const optimistic5y = currentValue * Math.pow(1.12, 5);
      const pessimistic5y = currentValue * Math.pow(0.97, 5);
      return {
        ticker: h.ticker,
        name: h.name,
        currentValue,
        invested,
        neutral5y: Math.round(neutral5y),
        optimistic5y: Math.round(optimistic5y),
        pessimistic5y: Math.round(pessimistic5y),
        neutralReturn: invested > 0 ? ((neutral5y - invested) / invested) * 100 : 0,
        currency: h.currency || "KRW",
      };
    });
  }, [holdingsWithPrices]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold tracking-tight">5년 시나리오 분석</h1>
        <p className="text-muted-foreground text-sm mt-1">
          포트폴리오의 미래 가치를 시나리오별로 예측합니다
        </p>
      </div>

      {/* Current Portfolio Status */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Card className="bg-card border-border">
          <CardContent className="p-5">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">총 투자원금</span>
              <DollarSign className="h-4 w-4 text-primary" />
            </div>
            <div className="text-xl font-bold tabular-nums">
              {isLoading ? <Skeleton className="h-7 w-32" /> : formatCurrency(summary?.totalInvested || 0)}
            </div>
          </CardContent>
        </Card>
        <Card className="bg-card border-border">
          <CardContent className="p-5">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">현재 평가액</span>
              <BarChart3 className="h-4 w-4 text-primary" />
            </div>
            <div className="text-xl font-bold tabular-nums">
              {isLoading ? <Skeleton className="h-7 w-32" /> : formatCurrency(portfolioScenario?.totalCurrentValue || summary?.totalValue || 0)}
            </div>
          </CardContent>
        </Card>
        <Card className="bg-card border-border">
          <CardContent className="p-5">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">보유 종목</span>
              <Briefcase className="h-4 w-4 text-primary" />
            </div>
            <div className="text-xl font-bold tabular-nums">
              {isLoading ? <Skeleton className="h-7 w-16" /> : `${holdings?.length || 0}개`}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Portfolio-Level Scenario Chart */}
      <Card className="bg-card border-border">
        <CardHeader className="pb-2">
          <CardTitle className="text-base font-semibold flex items-center gap-2">
            <Target className="h-4 w-4 text-primary" />
            포트폴리오 5년 예상 가치
          </CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <Skeleton className="h-[350px] w-full" />
          ) : portfolioChartData.length > 0 ? (
            <div className="space-y-4">
              <ResponsiveContainer width="100%" height={350}>
                <LineChart data={portfolioChartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.28 0.015 260)" vertical={false} />
                  <XAxis dataKey="year" stroke="oklch(0.5 0.015 260)" fontSize={12} tickLine={false} axisLine={false} />
                  <YAxis
                    stroke="oklch(0.5 0.015 260)"
                    fontSize={11}
                    tickLine={false}
                    axisLine={false}
                    tickFormatter={(v) => `${(v / 10000).toFixed(0)}만`}
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "oklch(0.19 0.015 260)",
                      border: "1px solid oklch(0.28 0.015 260)",
                      borderRadius: "8px",
                      fontSize: "12px",
                      color: "oklch(0.93 0.005 250)",
                    }}
                    formatter={(value: number) => [formatCurrency(value)]}
                  />
                  <Legend />
                  <Line type="monotone" dataKey="투자원금" stroke="oklch(0.5 0.015 260)" strokeWidth={1.5} strokeDasharray="6 3" dot={false} />
                  <Line type="monotone" dataKey="낙관" stroke="oklch(0.72 0.19 155)" strokeWidth={2.5} dot={{ r: 4, fill: "oklch(0.72 0.19 155)" }} />
                  <Line type="monotone" dataKey="중립" stroke="oklch(0.65 0.15 250)" strokeWidth={2.5} dot={{ r: 4, fill: "oklch(0.65 0.15 250)" }} />
                  <Line type="monotone" dataKey="비관" stroke="oklch(0.65 0.2 25)" strokeWidth={2.5} dot={{ r: 4, fill: "oklch(0.65 0.2 25)" }} />
                </LineChart>
              </ResponsiveContainer>

              {/* 5-Year Summary Cards */}
              {portfolioScenario && (
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <ScenarioSummaryCard
                    label="낙관 시나리오"
                    sublabel="연 12% 성장"
                    value={portfolioScenario.scenarios.optimistic[4].value}
                    invested={portfolioScenario.totalInvested}
                    icon={TrendingUp}
                    color="text-gain"
                  />
                  <ScenarioSummaryCard
                    label="중립 시나리오"
                    sublabel="연 5% 성장"
                    value={portfolioScenario.scenarios.neutral[4].value}
                    invested={portfolioScenario.totalInvested}
                    icon={Minus}
                    color="text-primary"
                  />
                  <ScenarioSummaryCard
                    label="비관 시나리오"
                    sublabel="연 -3% 하락"
                    value={portfolioScenario.scenarios.pessimistic[4].value}
                    invested={portfolioScenario.totalInvested}
                    icon={TrendingDown}
                    color="text-loss"
                  />
                </div>
              )}
            </div>
          ) : (
            <div className="h-[350px] flex items-center justify-center text-muted-foreground text-sm">
              <div className="text-center">
                <Target className="h-10 w-10 mx-auto mb-3 opacity-30" />
                <p>보유 종목이 없습니다</p>
                <p className="text-xs mt-1">종목을 추가하면 시나리오 분석이 가능합니다</p>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Per-Holding 5-Year Projections */}
      {holdingProjections.length > 0 && (
        <Card className="bg-card border-border">
          <CardHeader className="pb-2">
            <CardTitle className="text-base font-semibold flex items-center gap-2">
              <Briefcase className="h-4 w-4 text-primary" />
              종목별 5년 후 예상 (중립 시나리오)
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              {/* Bar Chart Comparison */}
              <ResponsiveContainer width="100%" height={Math.max(200, holdingProjections.length * 50)}>
                <BarChart data={holdingProjections} layout="vertical">
                  <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.28 0.015 260)" horizontal={false} />
                  <XAxis
                    type="number"
                    stroke="oklch(0.5 0.015 260)"
                    fontSize={11}
                    tickLine={false}
                    axisLine={false}
                    tickFormatter={(v) => `${(v / 10000).toFixed(0)}만`}
                  />
                  <YAxis type="category" dataKey="ticker" stroke="oklch(0.5 0.015 260)" fontSize={11} tickLine={false} axisLine={false} width={60} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "oklch(0.19 0.015 260)",
                      border: "1px solid oklch(0.28 0.015 260)",
                      borderRadius: "8px",
                      fontSize: "12px",
                      color: "oklch(0.93 0.005 250)",
                    }}
                    formatter={(value: number, name: string) => [formatCurrency(value), name === "currentValue" ? "현재 평가액" : name === "neutral5y" ? "5년 후 (중립)" : name]}
                  />
                  <Legend formatter={(value) => value === "currentValue" ? "현재 평가액" : "5년 후 (중립)"} />
                  <Bar dataKey="currentValue" fill="oklch(0.5 0.015 260)" radius={[0, 4, 4, 0]} barSize={16} />
                  <Bar dataKey="neutral5y" radius={[0, 4, 4, 0]} barSize={16}>
                    {holdingProjections.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.neutralReturn >= 0 ? "oklch(0.72 0.19 155)" : "oklch(0.65 0.2 25)"} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>

              {/* Detailed Table */}
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-border">
                      <th className="text-left py-3 px-3 text-muted-foreground font-medium text-xs uppercase tracking-wider">종목</th>
                      <th className="text-right py-3 px-3 text-muted-foreground font-medium text-xs uppercase tracking-wider">투자원금</th>
                      <th className="text-right py-3 px-3 text-muted-foreground font-medium text-xs uppercase tracking-wider">현재 평가액</th>
                      <th className="text-right py-3 px-3 text-muted-foreground font-medium text-xs uppercase tracking-wider hidden sm:table-cell">비관 (5년)</th>
                      <th className="text-right py-3 px-3 text-muted-foreground font-medium text-xs uppercase tracking-wider">중립 (5년)</th>
                      <th className="text-right py-3 px-3 text-muted-foreground font-medium text-xs uppercase tracking-wider hidden sm:table-cell">낙관 (5년)</th>
                      <th className="text-right py-3 px-3 text-muted-foreground font-medium text-xs uppercase tracking-wider">예상 수익률</th>
                    </tr>
                  </thead>
                  <tbody>
                    {holdingProjections.map((h) => {
                      const isGain = h.neutralReturn >= 0;
                      return (
                        <tr key={h.ticker} className="border-b border-border/50 hover:bg-accent/30 transition-colors">
                          <td className="py-3 px-3">
                            <div className="font-medium">{h.ticker}</div>
                            <div className="text-xs text-muted-foreground">{h.name}</div>
                          </td>
                          <td className="py-3 px-3 text-right tabular-nums">{formatCurrency(h.invested, h.currency)}</td>
                          <td className="py-3 px-3 text-right tabular-nums">{formatCurrency(h.currentValue, h.currency)}</td>
                          <td className="py-3 px-3 text-right tabular-nums text-loss hidden sm:table-cell">{formatCurrency(h.pessimistic5y, h.currency)}</td>
                          <td className="py-3 px-3 text-right tabular-nums font-medium">{formatCurrency(h.neutral5y, h.currency)}</td>
                          <td className="py-3 px-3 text-right tabular-nums text-gain hidden sm:table-cell">{formatCurrency(h.optimistic5y, h.currency)}</td>
                          <td className="py-3 px-3 text-right">
                            <Badge variant={isGain ? "default" : "destructive"} className="text-xs tabular-nums">
                              {formatPercent(h.neutralReturn)}
                            </Badge>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Methodology Note */}
      <Card className="bg-accent/10 border-border">
        <CardContent className="p-4">
          <p className="text-xs text-muted-foreground leading-relaxed">
            <strong className="text-foreground">분석 방법론:</strong> 시나리오 분석은 과거 수익률과 변동성을 기반으로 한 통계적 추정입니다.
            낙관 시나리오는 연 12% 성장, 중립 시나리오는 연 5% 성장, 비관 시나리오는 연 -3% 하락을 가정합니다.
            종목별 상세 페이지에서는 각 종목의 실제 과거 데이터를 기반으로 한 개별 시나리오를 확인할 수 있습니다.
            이 분석은 투자 조언이 아니며, 실제 투자 결과는 시장 상황에 따라 크게 달라질 수 있습니다.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}

function ScenarioSummaryCard({
  label,
  sublabel,
  value,
  invested,
  icon: Icon,
  color,
}: {
  label: string;
  sublabel: string;
  value: number;
  invested: number;
  icon: React.ComponentType<{ className?: string }>;
  color: string;
}) {
  const returnRate = invested > 0 ? ((value - invested) / invested) * 100 : 0;
  const profit = value - invested;

  return (
    <Card className="bg-secondary/30 border-border">
      <CardContent className="p-4">
        <div className="flex items-center gap-2 mb-3">
          <Icon className={`h-4 w-4 ${color}`} />
          <div>
            <p className="text-sm font-medium">{label}</p>
            <p className="text-xs text-muted-foreground">{sublabel}</p>
          </div>
        </div>
        <div className="space-y-1.5">
          <div className="flex justify-between">
            <span className="text-xs text-muted-foreground">5년 후 예상 가치</span>
            <span className="text-sm font-bold tabular-nums">{formatCurrency(value)}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-xs text-muted-foreground">예상 수익</span>
            <span className={`text-sm font-semibold tabular-nums ${profit >= 0 ? "text-gain" : "text-loss"}`}>
              {formatCurrency(profit)}
            </span>
          </div>
          <div className="flex justify-between">
            <span className="text-xs text-muted-foreground">예상 수익률</span>
            <span className={`text-sm font-semibold tabular-nums ${returnRate >= 0 ? "text-gain" : "text-loss"}`}>
              {formatPercent(returnRate)}
            </span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
