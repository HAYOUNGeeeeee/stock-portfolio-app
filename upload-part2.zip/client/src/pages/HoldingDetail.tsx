import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import {
  ArrowLeft,
  TrendingUp,
  TrendingDown,
  Plus,
  DollarSign,
  BarChart3,
  Calendar,
  Percent,
  RefreshCw,
  Target,
  Minus,
  Activity,
} from "lucide-react";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
  Legend,
} from "recharts";
import { useState, useMemo } from "react";
import { useLocation, useParams } from "wouter";
import { toast } from "sonner";

function formatCurrency(value: number, currency = "KRW") {
  if (currency === "USD") {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      maximumFractionDigits: 2,
    }).format(value);
  }
  return new Intl.NumberFormat("ko-KR", {
    style: "currency",
    currency: "KRW",
    maximumFractionDigits: 0,
  }).format(value);
}

function formatPercent(value: number) {
  return `${value >= 0 ? "+" : ""}${value.toFixed(2)}%`;
}

function formatDate(date: Date | string) {
  return new Date(date).toLocaleDateString("ko-KR", {
    year: "numeric",
    month: "short",
    day: "numeric",
  });
}

export default function HoldingDetail() {
  const params = useParams<{ id: string }>();
  const holdingId = Number(params.id);
  const [, setLocation] = useLocation();

  const { data: holding, isLoading: holdingLoading } =
    trpc.holdings.getById.useQuery({ id: holdingId });
  const { data: txns, isLoading: txnsLoading } =
    trpc.transactions.listByHolding.useQuery({ holdingId });

  // Real-time price
  const { data: livePrice, isLoading: priceLoading, refetch: refetchPrice } =
    trpc.stock.getPrice.useQuery(
      { ticker: holding?.ticker || "" },
      { enabled: !!holding?.ticker }
    );

  // Price history chart
  const [historyRange, setHistoryRange] = useState("1y");
  const { data: priceHistory, isLoading: historyLoading } =
    trpc.stock.getHistory.useQuery(
      { ticker: holding?.ticker || "", range: historyRange },
      { enabled: !!holding?.ticker }
    );

  // 5-year scenario
  const { data: scenario, isLoading: scenarioLoading } =
    trpc.stock.getScenario.useQuery(
      {
        ticker: holding?.ticker || "",
        currentPrice: livePrice?.price || Number(holding?.currentPrice) || Number(holding?.avgPrice) || 0,
        dividendYield: Number(holding?.dividendYield) || 0,
      },
      { enabled: !!holding?.ticker && (!!livePrice?.price || !!holding?.currentPrice) }
    );

  const utils = trpc.useUtils();

  const [showTxDialog, setShowTxDialog] = useState(false);
  const [txForm, setTxForm] = useState({
    type: "buy" as "buy" | "sell",
    quantity: "",
    price: "",
    fee: "",
    notes: "",
    transactionDate: new Date().toISOString().split("T")[0],
  });

  const createTxMutation = trpc.transactions.create.useMutation({
    onSuccess: () => {
      utils.transactions.listByHolding.invalidate({ holdingId });
      utils.holdings.getById.invalidate({ id: holdingId });
      utils.holdings.list.invalidate();
      utils.portfolio.summary.invalidate();
      setShowTxDialog(false);
      setTxForm({
        type: "buy",
        quantity: "",
        price: "",
        fee: "",
        notes: "",
        transactionDate: new Date().toISOString().split("T")[0],
      });
      toast.success("거래가 추가되었습니다");
    },
    onError: (err) => toast.error(err.message),
  });

  const handleTxSubmit = () => {
    if (!txForm.quantity || !txForm.price) {
      toast.error("수량과 가격을 입력해주세요");
      return;
    }
    createTxMutation.mutate({
      holdingId,
      type: txForm.type,
      quantity: txForm.quantity,
      price: txForm.price,
      fee: txForm.fee || "0",
      notes: txForm.notes || undefined,
      transactionDate: new Date(txForm.transactionDate),
    });
  };

  // Transaction chart data
  const txChartData = useMemo(() => {
    if (!txns || txns.length === 0) return [];
    const sorted = [...txns].sort(
      (a, b) => new Date(a.transactionDate).getTime() - new Date(b.transactionDate).getTime()
    );
    let cumQty = 0;
    let cumCost = 0;
    return sorted.map((tx) => {
      const qty = Number(tx.quantity);
      const price = Number(tx.price);
      if (tx.type === "buy") {
        cumCost += qty * price;
        cumQty += qty;
      } else {
        cumCost -= qty * price;
        cumQty -= qty;
      }
      return {
        date: formatDate(tx.transactionDate),
        totalCost: cumCost,
        avgPrice: cumQty > 0 ? cumCost / cumQty : 0,
        quantity: cumQty,
      };
    });
  }, [txns]);

  // Price history chart data
  const historyChartData = useMemo(() => {
    if (!priceHistory || priceHistory.length === 0) return [];
    return (priceHistory as any[]).map((p: any) => ({
      date: new Date(p.date).toLocaleDateString("ko-KR", { month: "short", day: "numeric" }),
      close: p.close,
      volume: p.volume,
    }));
  }, [priceHistory]);

  // Scenario chart data
  const scenarioChartData = useMemo(() => {
    if (!scenario) return [];
    return [0, 1, 2, 3, 4].map((i) => ({
      year: `${i + 1}년`,
      낙관: scenario.scenarios.optimistic[i]?.price || 0,
      중립: scenario.scenarios.neutral[i]?.price || 0,
      비관: scenario.scenarios.pessimistic[i]?.price || 0,
    }));
  }, [scenario]);

  if (holdingLoading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-8 w-48" />
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {[...Array(4)].map((_, i) => (
            <Skeleton key={i} className="h-24" />
          ))}
        </div>
        <Skeleton className="h-[400px]" />
      </div>
    );
  }

  if (!holding) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-muted-foreground">
        <p className="text-lg font-medium">종목을 찾을 수 없습니다</p>
        <Button variant="outline" className="mt-4 bg-transparent" onClick={() => setLocation("/holdings")}>
          <ArrowLeft className="h-4 w-4 mr-2" />
          종목 목록으로
        </Button>
      </div>
    );
  }

  const avg = Number(holding.avgPrice);
  const realTimePrice = livePrice?.price || Number(holding.currentPrice) || avg;
  const qty = Number(holding.quantity);
  const totalInvested = qty * avg;
  const totalValue = qty * realTimePrice;
  const totalReturn = totalValue - totalInvested;
  const returnRate = avg > 0 ? ((realTimePrice - avg) / avg) * 100 : 0;
  const isGain = returnRate >= 0;
  const cur = holding.currency || "KRW";

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="icon" className="h-9 w-9 shrink-0" onClick={() => setLocation("/holdings")}>
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-2xl font-bold tracking-tight">{holding.ticker}</h1>
              {holding.market && <Badge variant="secondary" className="text-xs">{holding.market}</Badge>}
              {livePrice && (
                <Badge variant="outline" className="text-xs gap-1">
                  <Activity className="h-3 w-3" />
                  실시간
                </Badge>
              )}
            </div>
            <p className="text-muted-foreground text-sm mt-0.5">
              {holding.name}
              {holding.sector && <span className="ml-2 text-xs">({holding.sector})</span>}
            </p>
          </div>
        </div>
        <div className="flex gap-2">
          <Button
            variant="outline"
            size="sm"
            className="gap-1.5 bg-transparent"
            onClick={() => {
              refetchPrice();
              toast.success("가격을 새로고침했습니다");
            }}
          >
            <RefreshCw className="h-3.5 w-3.5" />
            새로고침
          </Button>
          <Button size="sm" onClick={() => setShowTxDialog(true)} className="gap-1.5">
            <Plus className="h-3.5 w-3.5" />
            거래 추가
          </Button>
        </div>
      </div>

      {/* Live Price Banner */}
      <Card className="bg-gradient-to-r from-card to-accent/20 border-border">
        <CardContent className="p-5">
          <div className="flex flex-col sm:flex-row sm:items-end gap-4 sm:gap-8">
            <div>
              <p className="text-xs text-muted-foreground uppercase tracking-wider mb-1">현재가 (실시간)</p>
              <div className="flex items-baseline gap-3">
                <span className="text-3xl font-bold tabular-nums">{formatCurrency(realTimePrice, cur)}</span>
                {livePrice && (
                  <span className={`text-sm font-medium ${livePrice.change >= 0 ? "text-gain" : "text-loss"}`}>
                    {livePrice.change >= 0 ? "+" : ""}{formatCurrency(livePrice.change, cur)} ({formatPercent(livePrice.changePercent)})
                  </span>
                )}
              </div>
            </div>
            <div className="flex gap-6 text-sm">
              <div>
                <p className="text-xs text-muted-foreground">평균매수가</p>
                <p className="font-semibold tabular-nums">{formatCurrency(avg, cur)}</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">보유수량</p>
                <p className="font-semibold tabular-nums">{qty.toLocaleString()}주</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">평가금액</p>
                <p className="font-semibold tabular-nums">{formatCurrency(totalValue, cur)}</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Key Metrics */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricCard label="총 투자금" value={formatCurrency(totalInvested, cur)} icon={DollarSign} />
        <MetricCard label="평가금액" value={formatCurrency(totalValue, cur)} icon={BarChart3} />
        <MetricCard
          label="수익/손실"
          value={formatCurrency(totalReturn, cur)}
          icon={isGain ? TrendingUp : TrendingDown}
          trend={totalReturn}
          subtitle={formatPercent(returnRate)}
        />
        <MetricCard
          label="배당수익률"
          value={`${Number(holding.dividendYield || 0).toFixed(2)}%`}
          icon={Percent}
          subtitle={`연간 ${formatCurrency(totalValue * Number(holding.dividendYield || 0) / 100, cur)}`}
        />
      </div>

      {/* Tabbed Content */}
      <Tabs defaultValue="chart" className="space-y-4">
        <TabsList className="bg-secondary/50">
          <TabsTrigger value="chart">가격 차트</TabsTrigger>
          <TabsTrigger value="scenario">5년 시나리오</TabsTrigger>
          <TabsTrigger value="transactions">거래 이력</TabsTrigger>
          <TabsTrigger value="analysis">투자 분석</TabsTrigger>
        </TabsList>

        {/* Price Chart Tab */}
        <TabsContent value="chart" className="space-y-4">
          <Card className="bg-card border-border">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-base font-semibold flex items-center gap-2">
                  <Activity className="h-4 w-4 text-primary" />
                  가격 추이
                </CardTitle>
                <div className="flex gap-1">
                  {["1mo", "3mo", "6mo", "1y", "5y"].map((r) => (
                    <Button
                      key={r}
                      variant={historyRange === r ? "default" : "ghost"}
                      size="sm"
                      className="h-7 px-2 text-xs"
                      onClick={() => setHistoryRange(r)}
                    >
                      {r === "1mo" ? "1개월" : r === "3mo" ? "3개월" : r === "6mo" ? "6개월" : r === "1y" ? "1년" : "5년"}
                    </Button>
                  ))}
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {historyLoading ? (
                <Skeleton className="h-[300px] w-full" />
              ) : historyChartData.length > 0 ? (
                <ResponsiveContainer width="100%" height={300}>
                  <AreaChart data={historyChartData}>
                    <defs>
                      <linearGradient id="colorPrice" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="oklch(0.65 0.15 250)" stopOpacity={0.3} />
                        <stop offset="95%" stopColor="oklch(0.65 0.15 250)" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.28 0.015 260)" vertical={false} />
                    <XAxis dataKey="date" stroke="oklch(0.5 0.015 260)" fontSize={11} tickLine={false} axisLine={false} />
                    <YAxis stroke="oklch(0.5 0.015 260)" fontSize={11} tickLine={false} axisLine={false} domain={["auto", "auto"]} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "oklch(0.19 0.015 260)",
                        border: "1px solid oklch(0.28 0.015 260)",
                        borderRadius: "8px",
                        fontSize: "12px",
                        color: "oklch(0.93 0.005 250)",
                      }}
                      formatter={(value: number) => [formatCurrency(value, cur), "종가"]}
                    />
                    <Area type="monotone" dataKey="close" stroke="oklch(0.65 0.15 250)" strokeWidth={2} fill="url(#colorPrice)" />
                  </AreaChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-[300px] flex items-center justify-center text-muted-foreground text-sm">
                  <p>가격 데이터를 불러올 수 없습니다</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* 5-Year Scenario Tab */}
        <TabsContent value="scenario" className="space-y-4">
          <Card className="bg-card border-border">
            <CardHeader className="pb-2">
              <CardTitle className="text-base font-semibold flex items-center gap-2">
                <Target className="h-4 w-4 text-primary" />
                5년 후 시나리오 분석
              </CardTitle>
            </CardHeader>
            <CardContent>
              {scenarioLoading ? (
                <Skeleton className="h-[300px] w-full" />
              ) : scenario ? (
                <div className="space-y-6">
                  {/* Scenario Parameters */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                    <div className="bg-secondary/30 rounded-lg p-3">
                      <p className="text-xs text-muted-foreground">현재가</p>
                      <p className="font-semibold tabular-nums">{formatCurrency(scenario.currentPrice, cur)}</p>
                    </div>
                    <div className="bg-secondary/30 rounded-lg p-3">
                      <p className="text-xs text-muted-foreground">연간 수익률 (과거)</p>
                      <p className={`font-semibold tabular-nums ${scenario.annualReturn >= 0 ? "text-gain" : "text-loss"}`}>
                        {formatPercent(scenario.annualReturn)}
                      </p>
                    </div>
                    <div className="bg-secondary/30 rounded-lg p-3">
                      <p className="text-xs text-muted-foreground">연간 변동성</p>
                      <p className="font-semibold tabular-nums">{scenario.annualVolatility.toFixed(1)}%</p>
                    </div>
                    <div className="bg-secondary/30 rounded-lg p-3">
                      <p className="text-xs text-muted-foreground">배당수익률</p>
                      <p className="font-semibold tabular-nums">{scenario.dividendYield.toFixed(2)}%</p>
                    </div>
                  </div>

                  {/* Scenario Chart */}
                  <ResponsiveContainer width="100%" height={280}>
                    <LineChart data={scenarioChartData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.28 0.015 260)" vertical={false} />
                      <XAxis dataKey="year" stroke="oklch(0.5 0.015 260)" fontSize={12} tickLine={false} axisLine={false} />
                      <YAxis stroke="oklch(0.5 0.015 260)" fontSize={11} tickLine={false} axisLine={false} />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: "oklch(0.19 0.015 260)",
                          border: "1px solid oklch(0.28 0.015 260)",
                          borderRadius: "8px",
                          fontSize: "12px",
                          color: "oklch(0.93 0.005 250)",
                        }}
                        formatter={(value: number) => [formatCurrency(value, cur)]}
                      />
                      <Legend />
                      <Line type="monotone" dataKey="낙관" stroke="oklch(0.72 0.19 155)" strokeWidth={2} dot={{ r: 3 }} />
                      <Line type="monotone" dataKey="중립" stroke="oklch(0.65 0.15 250)" strokeWidth={2} dot={{ r: 3 }} />
                      <Line type="monotone" dataKey="비관" stroke="oklch(0.65 0.2 25)" strokeWidth={2} dot={{ r: 3 }} />
                    </LineChart>
                  </ResponsiveContainer>

                  {/* Scenario Table */}
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="border-b border-border">
                          <th className="text-left py-2 px-3 text-muted-foreground font-medium text-xs">시나리오</th>
                          {[1, 2, 3, 4, 5].map((y) => (
                            <th key={y} className="text-right py-2 px-3 text-muted-foreground font-medium text-xs">{y}년 후</th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {(["optimistic", "neutral", "pessimistic"] as const).map((type) => (
                          <tr key={type} className="border-b border-border/50">
                            <td className="py-2.5 px-3 font-medium">
                              <span className={`inline-flex items-center gap-1 ${type === "optimistic" ? "text-gain" : type === "pessimistic" ? "text-loss" : "text-primary"}`}>
                                {type === "optimistic" ? <TrendingUp className="h-3.5 w-3.5" /> : type === "pessimistic" ? <TrendingDown className="h-3.5 w-3.5" /> : <Minus className="h-3.5 w-3.5" />}
                                {type === "optimistic" ? "낙관" : type === "neutral" ? "중립" : "비관"}
                              </span>
                            </td>
                            {scenario.scenarios[type].map((s, i) => (
                              <td key={i} className="py-2.5 px-3 text-right tabular-nums">
                                <div className="text-xs">{formatCurrency(s.price, cur)}</div>
                                <div className={`text-xs ${s.totalReturn >= 0 ? "text-gain" : "text-loss"}`}>
                                  {formatPercent(s.totalReturn)}
                                </div>
                              </td>
                            ))}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>

                  {/* Portfolio Impact */}
                  {qty > 0 && (
                    <Card className="bg-accent/10 border-border">
                      <CardContent className="p-4">
                        <h4 className="text-sm font-semibold mb-3">내 포트폴리오 5년 후 예상 (중립 시나리오)</h4>
                        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                          <div>
                            <p className="text-xs text-muted-foreground">현재 평가액</p>
                            <p className="font-semibold tabular-nums">{formatCurrency(totalValue, cur)}</p>
                          </div>
                          <div>
                            <p className="text-xs text-muted-foreground">5년 후 예상 평가액</p>
                            <p className="font-semibold tabular-nums text-primary">
                              {formatCurrency(qty * (scenario.scenarios.neutral[4]?.price || realTimePrice), cur)}
                            </p>
                          </div>
                          <div>
                            <p className="text-xs text-muted-foreground">예상 수익</p>
                            <p className={`font-semibold tabular-nums ${(scenario.scenarios.neutral[4]?.totalReturn || 0) >= 0 ? "text-gain" : "text-loss"}`}>
                              {formatCurrency(qty * (scenario.scenarios.neutral[4]?.price || realTimePrice) - totalInvested, cur)}
                            </p>
                          </div>
                          <div>
                            <p className="text-xs text-muted-foreground">누적 배당금 (예상)</p>
                            <p className="font-semibold tabular-nums">
                              {formatCurrency(qty * (scenario.scenarios.neutral[4]?.dividend || 0), cur)}
                            </p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  )}
                </div>
              ) : (
                <div className="h-[300px] flex items-center justify-center text-muted-foreground text-sm">
                  <div className="text-center">
                    <Target className="h-10 w-10 mx-auto mb-3 opacity-30" />
                    <p>시나리오 데이터를 불러올 수 없습니다</p>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Transactions Tab */}
        <TabsContent value="transactions" className="space-y-4">
          {/* Investment Accumulation Chart */}
          <Card className="bg-card border-border">
            <CardHeader className="pb-2">
              <CardTitle className="text-base font-semibold flex items-center gap-2">
                <BarChart3 className="h-4 w-4 text-primary" />
                투자 누적 추이
              </CardTitle>
            </CardHeader>
            <CardContent>
              {txnsLoading ? (
                <Skeleton className="h-[220px] w-full" />
              ) : txChartData.length > 1 ? (
                <ResponsiveContainer width="100%" height={220}>
                  <AreaChart data={txChartData}>
                    <defs>
                      <linearGradient id="colorCost" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="oklch(0.65 0.15 250)" stopOpacity={0.3} />
                        <stop offset="95%" stopColor="oklch(0.65 0.15 250)" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.28 0.015 260)" vertical={false} />
                    <XAxis dataKey="date" stroke="oklch(0.5 0.015 260)" fontSize={11} tickLine={false} axisLine={false} />
                    <YAxis stroke="oklch(0.5 0.015 260)" fontSize={11} tickLine={false} axisLine={false} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "oklch(0.19 0.015 260)",
                        border: "1px solid oklch(0.28 0.015 260)",
                        borderRadius: "8px",
                        fontSize: "12px",
                        color: "oklch(0.93 0.005 250)",
                      }}
                      formatter={(value: number, name: string) => [
                        formatCurrency(value, cur),
                        name === "totalCost" ? "누적 투자금" : "평균단가",
                      ]}
                    />
                    <Area type="monotone" dataKey="totalCost" stroke="oklch(0.65 0.15 250)" strokeWidth={2} fill="url(#colorCost)" />
                  </AreaChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-[220px] flex items-center justify-center text-muted-foreground text-sm">
                  <p>거래 이력이 2건 이상이면 차트가 표시됩니다</p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Transaction Table */}
          <Card className="bg-card border-border">
            <CardHeader className="pb-2">
              <CardTitle className="text-base font-semibold flex items-center gap-2">
                <Calendar className="h-4 w-4 text-primary" />
                거래 이력
              </CardTitle>
            </CardHeader>
            <CardContent>
              {txnsLoading ? (
                <div className="space-y-3">
                  {[...Array(3)].map((_, i) => <Skeleton key={i} className="h-12 w-full" />)}
                </div>
              ) : txns && txns.length > 0 ? (
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-border">
                        <th className="text-left py-3 px-3 text-muted-foreground font-medium text-xs uppercase tracking-wider">날짜</th>
                        <th className="text-left py-3 px-3 text-muted-foreground font-medium text-xs uppercase tracking-wider">유형</th>
                        <th className="text-right py-3 px-3 text-muted-foreground font-medium text-xs uppercase tracking-wider">수량</th>
                        <th className="text-right py-3 px-3 text-muted-foreground font-medium text-xs uppercase tracking-wider">가격</th>
                        <th className="text-right py-3 px-3 text-muted-foreground font-medium text-xs uppercase tracking-wider hidden sm:table-cell">수수료</th>
                        <th className="text-right py-3 px-3 text-muted-foreground font-medium text-xs uppercase tracking-wider">총액</th>
                      </tr>
                    </thead>
                    <tbody>
                      {txns.map((tx) => (
                        <tr key={tx.id} className="border-b border-border/50 hover:bg-accent/30 transition-colors">
                          <td className="py-3 px-3 text-xs">{formatDate(tx.transactionDate)}</td>
                          <td className="py-3 px-3">
                            <Badge variant={tx.type === "buy" ? "default" : "destructive"} className="text-xs">
                              {tx.type === "buy" ? "매수" : "매도"}
                            </Badge>
                          </td>
                          <td className="py-3 px-3 text-right tabular-nums">{Number(tx.quantity).toLocaleString()}</td>
                          <td className="py-3 px-3 text-right tabular-nums">{formatCurrency(Number(tx.price), cur)}</td>
                          <td className="py-3 px-3 text-right tabular-nums text-muted-foreground hidden sm:table-cell">{formatCurrency(Number(tx.fee || 0), cur)}</td>
                          <td className="py-3 px-3 text-right tabular-nums font-medium">{formatCurrency(Number(tx.totalAmount), cur)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <div className="py-8 text-center text-muted-foreground text-sm">
                  <Calendar className="h-8 w-8 mx-auto mb-2 opacity-30" />
                  <p>거래 이력이 없습니다</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Analysis Tab */}
        <TabsContent value="analysis" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {/* Investment Summary */}
            <Card className="bg-card border-border">
              <CardHeader className="pb-2">
                <CardTitle className="text-base font-semibold">투자 요약</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <InfoRow label="티커" value={holding.ticker} />
                  <InfoRow label="종목명" value={holding.name} />
                  <InfoRow label="시장" value={holding.market || "-"} />
                  <InfoRow label="섹터" value={holding.sector || "-"} />
                  <InfoRow label="통화" value={cur} />
                  <InfoRow label="보유 수량" value={`${qty.toLocaleString()}주`} />
                  <InfoRow label="평균매수가" value={formatCurrency(avg, cur)} />
                  <InfoRow label="현재가 (실시간)" value={formatCurrency(realTimePrice, cur)} />
                  <InfoRow label="총 투자금" value={formatCurrency(totalInvested, cur)} />
                  <InfoRow label="현재 평가액" value={formatCurrency(totalValue, cur)} />
                  <InfoRow label="총 수익/손실" value={formatCurrency(totalReturn, cur)} className={isGain ? "text-gain" : "text-loss"} />
                  <InfoRow label="수익률" value={formatPercent(returnRate)} className={isGain ? "text-gain" : "text-loss"} />
                  <InfoRow label="배당수익률" value={`${Number(holding.dividendYield || 0).toFixed(2)}%`} />
                  <InfoRow label="예상 연간 배당금" value={formatCurrency(totalValue * Number(holding.dividendYield || 0) / 100, cur)} />
                  <InfoRow label="최초 매수일" value={formatDate(holding.createdAt)} />
                  <InfoRow label="거래 횟수" value={`${txns?.length || 0}건`} />
                </div>
              </CardContent>
            </Card>

            {/* Profit/Loss Breakdown */}
            <Card className="bg-card border-border">
              <CardHeader className="pb-2">
                <CardTitle className="text-base font-semibold">손익 분석</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {/* Visual P&L Bar */}
                  <div className="space-y-2">
                    <div className="flex justify-between text-xs text-muted-foreground">
                      <span>투자원금</span>
                      <span>현재 평가액</span>
                    </div>
                    <div className="relative h-8 bg-secondary/50 rounded-lg overflow-hidden">
                      <div
                        className={`absolute inset-y-0 left-0 rounded-lg transition-all ${isGain ? "bg-gain/30" : "bg-loss/30"}`}
                        style={{ width: `${Math.min(100, Math.max(5, (totalValue / Math.max(totalInvested, 1)) * 100))}%` }}
                      />
                      <div className="absolute inset-0 flex items-center justify-center text-xs font-medium">
                        {formatPercent(returnRate)}
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div className="bg-secondary/30 rounded-lg p-3">
                      <p className="text-xs text-muted-foreground">투자원금</p>
                      <p className="text-lg font-bold tabular-nums">{formatCurrency(totalInvested, cur)}</p>
                    </div>
                    <div className="bg-secondary/30 rounded-lg p-3">
                      <p className="text-xs text-muted-foreground">평가금액</p>
                      <p className="text-lg font-bold tabular-nums">{formatCurrency(totalValue, cur)}</p>
                    </div>
                    <div className={`rounded-lg p-3 ${isGain ? "bg-gain/10" : "bg-loss/10"}`}>
                      <p className="text-xs text-muted-foreground">평가손익</p>
                      <p className={`text-lg font-bold tabular-nums ${isGain ? "text-gain" : "text-loss"}`}>
                        {formatCurrency(totalReturn, cur)}
                      </p>
                    </div>
                    <div className={`rounded-lg p-3 ${isGain ? "bg-gain/10" : "bg-loss/10"}`}>
                      <p className="text-xs text-muted-foreground">수익률</p>
                      <p className={`text-lg font-bold tabular-nums ${isGain ? "text-gain" : "text-loss"}`}>
                        {formatPercent(returnRate)}
                      </p>
                    </div>
                  </div>

                  {/* Per-share breakdown */}
                  <div className="border-t border-border pt-3 space-y-2">
                    <h4 className="text-xs font-medium text-muted-foreground uppercase tracking-wider">주당 분석</h4>
                    <InfoRow label="주당 매수가" value={formatCurrency(avg, cur)} />
                    <InfoRow label="주당 현재가" value={formatCurrency(realTimePrice, cur)} />
                    <InfoRow
                      label="주당 손익"
                      value={formatCurrency(realTimePrice - avg, cur)}
                      className={isGain ? "text-gain" : "text-loss"}
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>

      {/* Add Transaction Dialog */}
      <Dialog open={showTxDialog} onOpenChange={setShowTxDialog}>
        <DialogContent className="sm:max-w-[450px] bg-card border-border">
          <DialogHeader>
            <DialogTitle>거래 추가</DialogTitle>
            <DialogDescription>
              {holding.ticker} ({holding.name}) 거래를 기록합니다
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="space-y-2">
              <Label>거래 유형</Label>
              <Select value={txForm.type} onValueChange={(v) => setTxForm({ ...txForm, type: v as "buy" | "sell" })}>
                <SelectTrigger className="bg-secondary/50"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="buy">매수</SelectItem>
                  <SelectItem value="sell">매도</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>수량 *</Label>
                <Input type="number" placeholder="0" value={txForm.quantity} onChange={(e) => setTxForm({ ...txForm, quantity: e.target.value })} className="bg-secondary/50" />
              </div>
              <div className="space-y-2">
                <Label>가격 *</Label>
                <Input type="number" placeholder="0" value={txForm.price} onChange={(e) => setTxForm({ ...txForm, price: e.target.value })} className="bg-secondary/50" />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>수수료</Label>
                <Input type="number" placeholder="0" value={txForm.fee} onChange={(e) => setTxForm({ ...txForm, fee: e.target.value })} className="bg-secondary/50" />
              </div>
              <div className="space-y-2">
                <Label>거래일</Label>
                <Input type="date" value={txForm.transactionDate} onChange={(e) => setTxForm({ ...txForm, transactionDate: e.target.value })} className="bg-secondary/50" />
              </div>
            </div>
            <div className="space-y-2">
              <Label>메모</Label>
              <Input placeholder="거래 메모 (선택)" value={txForm.notes} onChange={(e) => setTxForm({ ...txForm, notes: e.target.value })} className="bg-secondary/50" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowTxDialog(false)} className="bg-transparent">취소</Button>
            <Button onClick={handleTxSubmit} disabled={createTxMutation.isPending}>
              {createTxMutation.isPending ? "저장 중..." : "추가"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function MetricCard({
  label,
  value,
  icon: Icon,
  trend,
  subtitle,
}: {
  label: string;
  value: string;
  icon: React.ComponentType<{ className?: string }>;
  trend?: number;
  subtitle?: string;
}) {
  const isGain = trend !== undefined && trend >= 0;
  const isLoss = trend !== undefined && trend < 0;

  return (
    <Card className="bg-card border-border card-hover">
      <CardContent className="p-4">
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">{label}</span>
          <div className="h-7 w-7 rounded-md bg-primary/10 flex items-center justify-center">
            <Icon className="h-3.5 w-3.5 text-primary" />
          </div>
        </div>
        <div className={`text-lg font-bold tabular-nums ${isGain ? "text-gain" : isLoss ? "text-loss" : ""}`}>{value}</div>
        {subtitle && (
          <p className={`text-xs mt-0.5 ${isGain ? "text-gain" : isLoss ? "text-loss" : "text-muted-foreground"}`}>{subtitle}</p>
        )}
      </CardContent>
    </Card>
  );
}

function InfoRow({ label, value, className }: { label: string; value: string; className?: string }) {
  return (
    <div className="flex items-center justify-between py-1.5 border-b border-border/50 last:border-0">
      <span className="text-xs text-muted-foreground">{label}</span>
      <span className={`text-sm font-medium tabular-nums ${className || ""}`}>{value}</span>
    </div>
  );
}
