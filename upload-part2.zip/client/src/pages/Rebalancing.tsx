import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import {
  Plus,
  Trash2,
  Scale,
  TrendingUp,
  TrendingDown,
  Minus,
  ArrowRight,
  Target,
  PieChart,
  AlertTriangle,
} from "lucide-react";
import { useState, useMemo } from "react";
import { toast } from "sonner";
import {
  PieChart as RechartsPie,
  Pie,
  Cell,
  ResponsiveContainer,
  Tooltip,
  Legend,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  ReferenceLine,
} from "recharts";

function formatCurrency(value: number) {
  return new Intl.NumberFormat("ko-KR", {
    style: "currency",
    currency: "KRW",
    maximumFractionDigits: 0,
  }).format(value);
}

const CHART_COLORS = [
  "oklch(0.65 0.15 250)",
  "oklch(0.7 0.12 200)",
  "oklch(0.75 0.15 155)",
  "oklch(0.75 0.15 75)",
  "oklch(0.65 0.18 320)",
  "oklch(0.6 0.15 30)",
  "oklch(0.7 0.15 120)",
  "oklch(0.65 0.12 280)",
];

type TargetFormData = {
  targetType: "sector" | "ticker";
  targetKey: string;
  label: string;
  targetWeight: string;
};

const emptyForm: TargetFormData = {
  targetType: "sector",
  targetKey: "",
  label: "",
  targetWeight: "",
};

export default function Rebalancing() {
  const { data: targets, isLoading: targetsLoading } = trpc.targets.list.useQuery();
  const { data: comparison, isLoading: compLoading } = trpc.targets.compare.useQuery();
  const { data: holdings } = trpc.holdings.list.useQuery();
  const utils = trpc.useUtils();

  const [showDialog, setShowDialog] = useState(false);
  const [deleteId, setDeleteId] = useState<number | null>(null);
  const [form, setForm] = useState<TargetFormData>(emptyForm);

  const createMutation = trpc.targets.create.useMutation({
    onSuccess: () => {
      utils.targets.list.invalidate();
      utils.targets.compare.invalidate();
      setShowDialog(false);
      setForm(emptyForm);
      toast.success("목표가 추가되었습니다");
    },
    onError: (err) => toast.error(err.message),
  });

  const deleteMutation = trpc.targets.delete.useMutation({
    onSuccess: () => {
      utils.targets.list.invalidate();
      utils.targets.compare.invalidate();
      setDeleteId(null);
      toast.success("목표가 삭제되었습니다");
    },
    onError: (err) => toast.error(err.message),
  });

  // Available sectors/tickers for dropdown
  const availableSectors = useMemo(() => {
    if (!holdings) return [];
    const sectors = new Set(holdings.map((h) => h.sector || "미분류"));
    return Array.from(sectors);
  }, [holdings]);

  const availableTickers = useMemo(() => {
    if (!holdings) return [];
    return holdings.map((h) => ({ ticker: h.ticker, name: h.name }));
  }, [holdings]);

  const handleSubmit = () => {
    if (!form.targetKey || !form.label || !form.targetWeight) {
      toast.error("모든 항목을 입력해주세요");
      return;
    }
    const weight = Number(form.targetWeight);
    if (isNaN(weight) || weight <= 0 || weight > 100) {
      toast.error("목표 비중은 0~100 사이여야 합니다");
      return;
    }
    createMutation.mutate(form);
  };

  // Summary stats
  const totalTargetWeight = useMemo(() => {
    if (!targets) return 0;
    return targets.reduce((sum, t) => sum + Number(t.targetWeight), 0);
  }, [targets]);

  const needsRebalancing = useMemo(() => {
    if (!comparison?.comparison) return 0;
    return comparison.comparison.filter((c) => c.action !== "유지").length;
  }, [comparison]);

  // Chart data
  const pieData = useMemo(() => {
    if (!comparison?.comparison) return [];
    return comparison.comparison.map((c, i) => ({
      name: c.label,
      target: c.targetWeight,
      current: c.currentWeight,
      fill: CHART_COLORS[i % CHART_COLORS.length],
    }));
  }, [comparison]);

  const barData = useMemo(() => {
    if (!comparison?.comparison) return [];
    return comparison.comparison.map((c) => ({
      name: c.label.length > 8 ? c.label.slice(0, 8) + "..." : c.label,
      차이: c.diff,
      fill: c.diff > 0 ? "oklch(0.65 0.2 25)" : c.diff < 0 ? "oklch(0.65 0.15 250)" : "oklch(0.6 0.015 260)",
    }));
  }, [comparison]);

  const isLoading = targetsLoading || compLoading;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight flex items-center gap-2">
            <Scale className="h-6 w-6 text-primary" />
            리밸런싱 가이드
          </h1>
          <p className="text-muted-foreground text-sm mt-1">
            목표 포트폴리오를 설정하고 현재 배분과 비교하세요
          </p>
        </div>
        <Button
          onClick={() => {
            setForm(emptyForm);
            setShowDialog(true);
          }}
          className="gap-2"
        >
          <Plus className="h-4 w-4" />
          목표 추가
        </Button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Card className="bg-card border-border">
          <CardContent className="p-5">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground">총 목표 비중</p>
                <p className="text-2xl font-bold mt-1 tabular-nums">
                  {totalTargetWeight.toFixed(1)}%
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  {totalTargetWeight === 100
                    ? "완벽한 배분"
                    : totalTargetWeight > 100
                    ? `${(totalTargetWeight - 100).toFixed(1)}% 초과`
                    : `${(100 - totalTargetWeight).toFixed(1)}% 미배분`}
                </p>
              </div>
              <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
                <Target className="h-5 w-5 text-primary" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-5">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground">설정된 목표</p>
                <p className="text-2xl font-bold mt-1 tabular-nums">
                  {targets?.length || 0}개
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  섹터/종목별 목표
                </p>
              </div>
              <div className="h-10 w-10 rounded-lg bg-chart-2/10 flex items-center justify-center">
                <PieChart className="h-5 w-5 text-chart-2" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-5">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground">조정 필요</p>
                <p className="text-2xl font-bold mt-1 tabular-nums">
                  {needsRebalancing}개
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  {needsRebalancing === 0 ? "균형 상태" : "리밸런싱 권장"}
                </p>
              </div>
              <div className={`h-10 w-10 rounded-lg flex items-center justify-center ${needsRebalancing > 0 ? "bg-warning/10" : "bg-success/10"}`}>
                {needsRebalancing > 0 ? (
                  <AlertTriangle className="h-5 w-5 text-warning" />
                ) : (
                  <Scale className="h-5 w-5 text-success" />
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts Row */}
      {comparison?.comparison && comparison.comparison.length > 0 && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {/* Target vs Current Pie */}
          <Card className="bg-card border-border">
            <CardHeader className="pb-2">
              <CardTitle className="text-base font-semibold flex items-center gap-2">
                <PieChart className="h-4 w-4 text-primary" />
                목표 vs 현재 배분
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-xs text-muted-foreground text-center mb-2">목표</p>
                  <ResponsiveContainer width="100%" height={200}>
                    <RechartsPie>
                      <Pie
                        data={pieData}
                        dataKey="target"
                        nameKey="name"
                        cx="50%"
                        cy="50%"
                        outerRadius={80}
                        innerRadius={40}
                        strokeWidth={2}
                        stroke="oklch(0.13 0.015 260)"
                      >
                        {pieData.map((entry, index) => (
                          <Cell key={index} fill={entry.fill} />
                        ))}
                      </Pie>
                      <Tooltip
                        contentStyle={{
                          backgroundColor: "oklch(0.19 0.015 260)",
                          border: "1px solid oklch(0.28 0.015 260)",
                          borderRadius: "8px",
                          color: "oklch(0.93 0.005 250)",
                        }}
                        formatter={(value: number) => [`${value.toFixed(1)}%`, ""]}
                      />
                    </RechartsPie>
                  </ResponsiveContainer>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground text-center mb-2">현재</p>
                  <ResponsiveContainer width="100%" height={200}>
                    <RechartsPie>
                      <Pie
                        data={pieData}
                        dataKey="current"
                        nameKey="name"
                        cx="50%"
                        cy="50%"
                        outerRadius={80}
                        innerRadius={40}
                        strokeWidth={2}
                        stroke="oklch(0.13 0.015 260)"
                      >
                        {pieData.map((entry, index) => (
                          <Cell key={index} fill={entry.fill} opacity={0.7} />
                        ))}
                      </Pie>
                      <Tooltip
                        contentStyle={{
                          backgroundColor: "oklch(0.19 0.015 260)",
                          border: "1px solid oklch(0.28 0.015 260)",
                          borderRadius: "8px",
                          color: "oklch(0.93 0.005 250)",
                        }}
                        formatter={(value: number) => [`${value.toFixed(1)}%`, ""]}
                      />
                    </RechartsPie>
                  </ResponsiveContainer>
                </div>
              </div>
              <div className="flex flex-wrap gap-2 mt-4 justify-center">
                {pieData.map((entry, i) => (
                  <div key={i} className="flex items-center gap-1.5 text-xs">
                    <div className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: entry.fill }} />
                    <span className="text-muted-foreground">{entry.name}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Deviation Bar Chart */}
          <Card className="bg-card border-border">
            <CardHeader className="pb-2">
              <CardTitle className="text-base font-semibold flex items-center gap-2">
                <Scale className="h-4 w-4 text-primary" />
                배분 차이 (현재 - 목표)
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={260}>
                <BarChart data={barData} layout="vertical" margin={{ left: 10, right: 20 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.25 0.015 260)" />
                  <XAxis
                    type="number"
                    tick={{ fill: "oklch(0.6 0.015 260)", fontSize: 11 }}
                    tickFormatter={(v) => `${v > 0 ? "+" : ""}${v.toFixed(1)}%`}
                  />
                  <YAxis
                    type="category"
                    dataKey="name"
                    tick={{ fill: "oklch(0.6 0.015 260)", fontSize: 11 }}
                    width={70}
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "oklch(0.19 0.015 260)",
                      border: "1px solid oklch(0.28 0.015 260)",
                      borderRadius: "8px",
                      color: "oklch(0.93 0.005 250)",
                    }}
                    formatter={(value: number) => [`${value > 0 ? "+" : ""}${value.toFixed(2)}%`, "차이"]}
                  />
                  <ReferenceLine x={0} stroke="oklch(0.4 0.015 260)" />
                  <Bar dataKey="차이" radius={[0, 4, 4, 0]}>
                    {barData.map((entry, index) => (
                      <Cell key={index} fill={entry.fill} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Rebalancing Table */}
      <Card className="bg-card border-border">
        <CardHeader className="pb-2">
          <CardTitle className="text-base font-semibold">리밸런싱 상세</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="p-6 space-y-4">
              {[...Array(4)].map((_, i) => (
                <Skeleton key={i} className="h-14 w-full" />
              ))}
            </div>
          ) : !comparison?.comparison || comparison.comparison.length === 0 ? (
            <div className="p-12 text-center text-muted-foreground">
              <Target className="h-10 w-10 mx-auto mb-3 opacity-30" />
              <p className="font-medium">설정된 목표가 없습니다</p>
              <p className="text-xs mt-1">"목표 추가" 버튼으로 시작하세요</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border">
                    <th className="text-left py-3 px-4 text-muted-foreground font-medium text-xs uppercase tracking-wider">항목</th>
                    <th className="text-center py-3 px-4 text-muted-foreground font-medium text-xs uppercase tracking-wider">유형</th>
                    <th className="text-right py-3 px-4 text-muted-foreground font-medium text-xs uppercase tracking-wider">목표</th>
                    <th className="text-right py-3 px-4 text-muted-foreground font-medium text-xs uppercase tracking-wider">현재</th>
                    <th className="text-right py-3 px-4 text-muted-foreground font-medium text-xs uppercase tracking-wider">차이</th>
                    <th className="text-right py-3 px-4 text-muted-foreground font-medium text-xs uppercase tracking-wider hidden sm:table-cell">조정 금액</th>
                    <th className="text-center py-3 px-4 text-muted-foreground font-medium text-xs uppercase tracking-wider">권장</th>
                    <th className="text-right py-3 px-4 text-muted-foreground font-medium text-xs uppercase tracking-wider">작업</th>
                  </tr>
                </thead>
                <tbody>
                  {comparison.comparison.map((c) => {
                    const isOver = c.diff > 1;
                    const isUnder = c.diff < -1;
                    return (
                      <tr key={c.id} className="border-b border-border/50 hover:bg-accent/30 transition-colors">
                        <td className="py-3 px-4">
                          <div className="font-semibold">{c.label}</div>
                          <div className="text-xs text-muted-foreground">{c.targetKey}</div>
                        </td>
                        <td className="py-3 px-4 text-center">
                          <Badge variant="secondary" className="text-xs">
                            {c.targetType === "sector" ? "섹터" : "종목"}
                          </Badge>
                        </td>
                        <td className="py-3 px-4 text-right tabular-nums font-medium">{c.targetWeight.toFixed(1)}%</td>
                        <td className="py-3 px-4 text-right tabular-nums">{c.currentWeight.toFixed(1)}%</td>
                        <td className="py-3 px-4 text-right">
                          <span className={`tabular-nums font-medium ${isOver ? "text-loss" : isUnder ? "text-gain" : "text-muted-foreground"}`}>
                            {c.diff > 0 ? "+" : ""}{c.diff.toFixed(1)}%
                          </span>
                        </td>
                        <td className="py-3 px-4 text-right tabular-nums hidden sm:table-cell">
                          <span className={isOver ? "text-loss" : isUnder ? "text-gain" : "text-muted-foreground"}>
                            {c.diffAmount > 0 ? "+" : ""}{formatCurrency(Math.abs(c.diffAmount))}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-center">
                          {c.action === "매도 검토" ? (
                            <Badge variant="destructive" className="text-xs gap-1">
                              <TrendingDown className="h-3 w-3" />
                              매도 검토
                            </Badge>
                          ) : c.action === "매수 검토" ? (
                            <Badge className="text-xs gap-1 bg-primary">
                              <TrendingUp className="h-3 w-3" />
                              매수 검토
                            </Badge>
                          ) : (
                            <Badge variant="secondary" className="text-xs gap-1">
                              <Minus className="h-3 w-3" />
                              유지
                            </Badge>
                          )}
                        </td>
                        <td className="py-3 px-4 text-right">
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8 text-muted-foreground hover:text-destructive"
                            onClick={() => setDeleteId(c.id)}
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </Button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Add Target Dialog */}
      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="sm:max-w-[450px] bg-card border-border">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Target className="h-5 w-5 text-primary" />
              목표 추가
            </DialogTitle>
            <DialogDescription>
              섹터 또는 종목별 목표 비중을 설정합니다
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="space-y-2">
              <Label>유형</Label>
              <Select
                value={form.targetType}
                onValueChange={(v: "sector" | "ticker") => {
                  setForm({ ...form, targetType: v, targetKey: "", label: "" });
                }}
              >
                <SelectTrigger className="bg-secondary/50">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="sector">섹터별</SelectItem>
                  <SelectItem value="ticker">종목별</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {form.targetType === "sector" ? (
              <div className="space-y-2">
                <Label>섹터</Label>
                {availableSectors.length > 0 ? (
                  <Select
                    value={form.targetKey}
                    onValueChange={(v) => setForm({ ...form, targetKey: v, label: v })}
                  >
                    <SelectTrigger className="bg-secondary/50">
                      <SelectValue placeholder="섹터 선택" />
                    </SelectTrigger>
                    <SelectContent>
                      {availableSectors.map((s) => (
                        <SelectItem key={s} value={s}>{s}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                ) : (
                  <Input
                    placeholder="섹터명 입력"
                    value={form.targetKey}
                    onChange={(e) => setForm({ ...form, targetKey: e.target.value, label: e.target.value })}
                    className="bg-secondary/50"
                  />
                )}
              </div>
            ) : (
              <div className="space-y-2">
                <Label>종목</Label>
                {availableTickers.length > 0 ? (
                  <Select
                    value={form.targetKey}
                    onValueChange={(v) => {
                      const ticker = availableTickers.find((t) => t.ticker === v);
                      setForm({ ...form, targetKey: v, label: ticker?.name || v });
                    }}
                  >
                    <SelectTrigger className="bg-secondary/50">
                      <SelectValue placeholder="종목 선택" />
                    </SelectTrigger>
                    <SelectContent>
                      {availableTickers.map((t) => (
                        <SelectItem key={t.ticker} value={t.ticker}>
                          {t.ticker} - {t.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                ) : (
                  <Input
                    placeholder="티커 입력"
                    value={form.targetKey}
                    onChange={(e) => setForm({ ...form, targetKey: e.target.value, label: e.target.value })}
                    className="bg-secondary/50"
                  />
                )}
              </div>
            )}

            <div className="space-y-2">
              <Label>목표 비중 (%)</Label>
              <Input
                type="number"
                min="0"
                max="100"
                step="0.1"
                placeholder="예: 25.0"
                value={form.targetWeight}
                onChange={(e) => setForm({ ...form, targetWeight: e.target.value })}
                className="bg-secondary/50"
              />
              {totalTargetWeight + Number(form.targetWeight || 0) > 100 && (
                <p className="text-xs text-warning">
                  총 비중이 100%를 초과합니다 ({(totalTargetWeight + Number(form.targetWeight || 0)).toFixed(1)}%)
                </p>
              )}
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDialog(false)} className="bg-transparent">
              취소
            </Button>
            <Button onClick={handleSubmit} disabled={createMutation.isPending}>
              {createMutation.isPending ? "추가 중..." : "추가"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <AlertDialog open={deleteId !== null} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent className="bg-card border-border">
          <AlertDialogHeader>
            <AlertDialogTitle>목표 삭제</AlertDialogTitle>
            <AlertDialogDescription>
              이 목표 설정을 삭제하시겠습니까?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="bg-transparent">취소</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => deleteId && deleteMutation.mutate({ id: deleteId })}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              삭제
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
