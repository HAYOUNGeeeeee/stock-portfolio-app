import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import {
  Plus,
  Trash2,
  Bell,
  BellOff,
  BellRing,
  TrendingUp,
  TrendingDown,
  ArrowUp,
  ArrowDown,
  Target,
  Percent,
  DollarSign,
  CheckCircle2,
  Clock,
  RefreshCw,
} from "lucide-react";
import { useState, useMemo } from "react";
import { toast } from "sonner";

function formatCurrency(value: number, currency = "KRW") {
  if (currency === "USD") {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      maximumFractionDigits: 2,
    }).format(value);
  }
  return new Intl.NumberFormat("ko-KR", {
    style: "currency",
    currency: "KRW",
    maximumFractionDigits: 0,
  }).format(value);
}

type AlertFormData = {
  holdingId: string;
  alertType: "price_above" | "price_below" | "return_above" | "return_below";
  targetValue: string;
};

const emptyForm: AlertFormData = {
  holdingId: "",
  alertType: "price_above",
  targetValue: "",
};

const alertTypeLabels: Record<string, { label: string; icon: typeof ArrowUp; color: string }> = {
  price_above: { label: "목표가 이상", icon: ArrowUp, color: "text-gain" },
  price_below: { label: "목표가 이하", icon: ArrowDown, color: "text-loss" },
  return_above: { label: "수익률 이상", icon: TrendingUp, color: "text-gain" },
  return_below: { label: "수익률 이하", icon: TrendingDown, color: "text-loss" },
};

export default function Alerts() {
  const { data: alerts, isLoading } = trpc.alerts.list.useQuery();
  const { data: holdings } = trpc.holdings.list.useQuery();
  const utils = trpc.useUtils();

  const [showDialog, setShowDialog] = useState(false);
  const [deleteId, setDeleteId] = useState<number | null>(null);
  const [form, setForm] = useState<AlertFormData>(emptyForm);
  const [filterStatus, setFilterStatus] = useState<"all" | "active" | "triggered">("all");

  const createMutation = trpc.alerts.create.useMutation({
    onSuccess: () => {
      utils.alerts.list.invalidate();
      setShowDialog(false);
      setForm(emptyForm);
      toast.success("알림이 설정되었습니다");
    },
    onError: (err) => toast.error(err.message),
  });

  const toggleMutation = trpc.alerts.update.useMutation({
    onSuccess: () => {
      utils.alerts.list.invalidate();
      toast.success("알림 상태가 변경되었습니다");
    },
    onError: (err: any) => toast.error(err.message),
  });

  const deleteMutation = trpc.alerts.delete.useMutation({
    onSuccess: () => {
      utils.alerts.list.invalidate();
      setDeleteId(null);
      toast.success("알림이 삭제되었습니다");
    },
    onError: (err) => toast.error(err.message),
  });

  const checkMutation = trpc.alerts.check.useMutation({
    onSuccess: (data) => {
      utils.alerts.list.invalidate();
      if (data.triggered.length > 0) {
        toast.success(`${data.triggered.length}개 알림이 트리거되었습니다!`);
      } else {
        toast.info("현재 트리거된 알림이 없습니다");
      }
    },
    onError: (err: any) => toast.error(err.message),
  });

  const filteredAlerts = useMemo(() => {
    if (!alerts) return [];
    if (filterStatus === "active") return alerts.filter((a) => a.status === "active" && !a.triggeredAt);
    if (filterStatus === "triggered") return alerts.filter((a) => a.triggeredAt);
    return alerts;
  }, [alerts, filterStatus]);

  // Stats
  const stats = useMemo(() => {
    if (!alerts) return { total: 0, active: 0, triggered: 0 };
    return {
      total: alerts.length,
      active: alerts.filter((a) => a.status === "active" && !a.triggeredAt).length,
      triggered: alerts.filter((a) => a.triggeredAt).length,
    };
  }, [alerts]);

  const handleSubmit = () => {
    if (!form.holdingId || !form.targetValue) {
      toast.error("모든 항목을 입력해주세요");
      return;
    }
    const selectedHolding = holdings?.find((h) => h.id === Number(form.holdingId));
    if (!selectedHolding) {
      toast.error("종목을 선택해주세요");
      return;
    }
    createMutation.mutate({
      holdingId: selectedHolding.id,
      ticker: selectedHolding.ticker,
      name: selectedHolding.name,
      alertType: form.alertType,
      targetValue: form.targetValue,
    });
  };

  const isReturnType = form.alertType === "return_above" || form.alertType === "return_below";

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight flex items-center gap-2">
            <Bell className="h-6 w-6 text-primary" />
            알림 관리
          </h1>
          <p className="text-muted-foreground text-sm mt-1">
            목표가 도달 및 수익률 기준 알림을 설정하세요
          </p>
        </div>
        <div className="flex gap-2">
          <Button
            variant="outline"
            size="sm"
            className="gap-2 bg-transparent"
            onClick={() => checkMutation.mutate()}
            disabled={checkMutation.isPending || !alerts || alerts.length === 0}
          >
            <RefreshCw className={`h-4 w-4 ${checkMutation.isPending ? "animate-spin" : ""}`} />
            <span className="hidden sm:inline">{checkMutation.isPending ? "확인 중..." : "알림 체크"}</span>
          </Button>
          <Button
            onClick={() => {
              setForm(emptyForm);
              setShowDialog(true);
            }}
            className="gap-2"
          >
            <Plus className="h-4 w-4" />
            알림 추가
          </Button>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Card className="bg-card border-border">
          <CardContent className="p-5">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground">전체 알림</p>
                <p className="text-2xl font-bold mt-1 tabular-nums">{stats.total}개</p>
              </div>
              <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
                <Bell className="h-5 w-5 text-primary" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-5">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground">활성 알림</p>
                <p className="text-2xl font-bold mt-1 tabular-nums">{stats.active}개</p>
              </div>
              <div className="h-10 w-10 rounded-lg bg-success/10 flex items-center justify-center">
                <BellRing className="h-5 w-5 text-success" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-5">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground">트리거됨</p>
                <p className="text-2xl font-bold mt-1 tabular-nums">{stats.triggered}개</p>
              </div>
              <div className="h-10 w-10 rounded-lg bg-warning/10 flex items-center justify-center">
                <CheckCircle2 className="h-5 w-5 text-warning" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filter */}
      <div className="flex gap-2">
        {(["all", "active", "triggered"] as const).map((status) => (
          <Button
            key={status}
            variant={filterStatus === status ? "default" : "outline"}
            size="sm"
            onClick={() => setFilterStatus(status)}
            className={filterStatus !== status ? "bg-transparent" : ""}
          >
            {status === "all" ? "전체" : status === "active" ? "활성" : "트리거됨"}
          </Button>
        ))}
      </div>

      {/* Alerts List */}
      <div className="space-y-3">
        {isLoading ? (
          [...Array(4)].map((_, i) => (
            <Skeleton key={i} className="h-20 w-full rounded-lg" />
          ))
        ) : filteredAlerts.length === 0 ? (
          <Card className="bg-card border-border">
            <CardContent className="p-12 text-center text-muted-foreground">
              <BellOff className="h-10 w-10 mx-auto mb-3 opacity-30" />
              <p className="font-medium">
                {filterStatus === "all" ? "설정된 알림이 없습니다" : `${filterStatus === "active" ? "활성" : "트리거된"} 알림이 없습니다`}
              </p>
              <p className="text-xs mt-1">"알림 추가" 버튼으로 시작하세요</p>
            </CardContent>
          </Card>
        ) : (
          filteredAlerts.map((alert) => {
            const typeInfo = alertTypeLabels[alert.alertType] || alertTypeLabels.price_above;
            const TypeIcon = typeInfo.icon;
            const isTriggered = !!alert.triggeredAt;
            const isReturn = alert.alertType.startsWith("return_");

            return (
              <Card
                key={alert.id}
                className={`bg-card border-border transition-all ${
                  isTriggered ? "border-warning/30 bg-warning/5" : alert.status !== "active" ? "opacity-60" : ""
                }`}
              >
                <CardContent className="p-4">
                  <div className="flex items-center justify-between gap-4">
                    <div className="flex items-center gap-4 flex-1">
                      {/* Icon */}
                      <div className={`h-10 w-10 rounded-lg flex items-center justify-center shrink-0 ${
                        isTriggered ? "bg-warning/10" : alert.status === "active" ? "bg-primary/10" : "bg-muted"
                      }`}>
                        {isTriggered ? (
                          <CheckCircle2 className="h-5 w-5 text-warning" />
                        ) : (
                          <TypeIcon className={`h-5 w-5 ${alert.status === "active" ? typeInfo.color : "text-muted-foreground"}`} />
                        )}
                      </div>

                      {/* Info */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-semibold">{alert.ticker}</span>
                          <span className="text-xs text-muted-foreground">{alert.name}</span>
                          <Badge variant={isTriggered ? "secondary" : "outline"} className="text-xs">
                            {typeInfo.label}
                          </Badge>
                          {isTriggered && (
                            <Badge variant="secondary" className="text-xs bg-warning/20 text-warning border-warning/30">
                              트리거됨
                            </Badge>
                          )}
                        </div>
                        <div className="flex items-center gap-3 mt-1 text-sm">
                          <span className="flex items-center gap-1 text-muted-foreground">
                            {isReturn ? <Percent className="h-3 w-3" /> : <DollarSign className="h-3 w-3" />}
                            목표: <span className="font-medium text-foreground">
                              {isReturn ? `${Number(alert.targetValue).toFixed(1)}%` : formatCurrency(Number(alert.targetValue))}
                            </span>
                          </span>
                          {isTriggered && alert.triggeredAt && (
                            <span className="flex items-center gap-1 text-xs text-muted-foreground">
                              <Clock className="h-3 w-3" />
                              {new Date(alert.triggeredAt).toLocaleDateString("ko-KR")}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="flex items-center gap-3 shrink-0">
                      <Switch
                        checked={alert.status === "active"}
                        onCheckedChange={() => toggleMutation.mutate({ id: alert.id, status: alert.status === "active" ? "paused" : "active" })}
                      />
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 text-muted-foreground hover:text-destructive"
                        onClick={() => setDeleteId(alert.id)}
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })
        )}
      </div>

      {/* Add Alert Dialog */}
      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="sm:max-w-[450px] bg-card border-border">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Bell className="h-5 w-5 text-primary" />
              알림 추가
            </DialogTitle>
            <DialogDescription>
              종목의 목표가 또는 수익률 기준을 설정합니다
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="space-y-2">
              <Label>종목</Label>
              {holdings && holdings.length > 0 ? (
                <Select
                  value={form.holdingId}
                  onValueChange={(v) => setForm({ ...form, holdingId: v })}
                >
                  <SelectTrigger className="bg-secondary/50">
                    <SelectValue placeholder="종목 선택" />
                  </SelectTrigger>
                  <SelectContent>
                    {holdings.map((h) => (
                      <SelectItem key={h.id} value={String(h.id)}>
                        {h.ticker} - {h.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              ) : (
                <p className="text-sm text-muted-foreground">보유 종목이 없습니다. 먼저 종목을 추가하세요.</p>
              )}
            </div>

            <div className="space-y-2">
              <Label>알림 유형</Label>
              <Select
                value={form.alertType}
                onValueChange={(v: AlertFormData["alertType"]) => setForm({ ...form, alertType: v })}
              >
                <SelectTrigger className="bg-secondary/50">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="price_above">
                    <span className="flex items-center gap-2">
                      <ArrowUp className="h-3.5 w-3.5 text-gain" />
                      가격이 목표가 이상일 때
                    </span>
                  </SelectItem>
                  <SelectItem value="price_below">
                    <span className="flex items-center gap-2">
                      <ArrowDown className="h-3.5 w-3.5 text-loss" />
                      가격이 목표가 이하일 때
                    </span>
                  </SelectItem>
                  <SelectItem value="return_above">
                    <span className="flex items-center gap-2">
                      <TrendingUp className="h-3.5 w-3.5 text-gain" />
                      수익률이 기준 이상일 때
                    </span>
                  </SelectItem>
                  <SelectItem value="return_below">
                    <span className="flex items-center gap-2">
                      <TrendingDown className="h-3.5 w-3.5 text-loss" />
                      수익률이 기준 이하일 때
                    </span>
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>{isReturnType ? "목표 수익률 (%)" : "목표 가격"}</Label>
              <Input
                type="number"
                step={isReturnType ? "0.1" : "1"}
                placeholder={isReturnType ? "예: 10.0" : "예: 150000"}
                value={form.targetValue}
                onChange={(e) => setForm({ ...form, targetValue: e.target.value })}
                className="bg-secondary/50"
              />
              {form.holdingId && holdings && (
                <p className="text-xs text-muted-foreground">
                  현재 매수가: {formatCurrency(Number(holdings.find((h) => h.id === Number(form.holdingId))?.avgPrice || 0))}
                </p>
              )}
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDialog(false)} className="bg-transparent">
              취소
            </Button>
            <Button onClick={handleSubmit} disabled={createMutation.isPending || !holdings || holdings.length === 0}>
              {createMutation.isPending ? "추가 중..." : "추가"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <AlertDialog open={deleteId !== null} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent className="bg-card border-border">
          <AlertDialogHeader>
            <AlertDialogTitle>알림 삭제</AlertDialogTitle>
            <AlertDialogDescription>
              이 알림을 삭제하시겠습니까?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="bg-transparent">취소</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => deleteId && deleteMutation.mutate({ id: deleteId })}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              삭제
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
