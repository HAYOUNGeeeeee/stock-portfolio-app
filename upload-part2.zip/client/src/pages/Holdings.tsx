import { trpc } from "@/lib/trpc";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Plus,
  Pencil,
  Trash2,
  TrendingUp,
  TrendingDown,
  Search,
  ExternalLink,
  RefreshCw,
  Zap,
  Download,
  Upload,
  FileSpreadsheet,
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useState, useMemo } from "react";
import { useLocation } from "wouter";
import { toast } from "sonner";

function formatCurrency(value: number, currency = "KRW") {
  if (currency === "USD") {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      maximumFractionDigits: 2,
    }).format(value);
  }
  return new Intl.NumberFormat("ko-KR", {
    style: "currency",
    currency: "KRW",
    maximumFractionDigits: 0,
  }).format(value);
}

function formatPercent(value: number) {
  return `${value >= 0 ? "+" : ""}${value.toFixed(2)}%`;
}

type HoldingFormData = {
  ticker: string;
  name: string;
  quantity: string;
  avgPrice: string;
  currentPrice: string;
  sector: string;
  market: string;
  currency: string;
  dividendYield: string;
  notes: string;
};

const emptyForm: HoldingFormData = {
  ticker: "",
  name: "",
  quantity: "",
  avgPrice: "",
  currentPrice: "",
  sector: "",
  market: "",
  currency: "KRW",
  dividendYield: "",
  notes: "",
};

export default function Holdings() {
  const [, setLocation] = useLocation();
  const { data: holdings, isLoading } = trpc.holdings.list.useQuery();
  const utils = trpc.useUtils();

  const [showDialog, setShowDialog] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [deleteId, setDeleteId] = useState<number | null>(null);
  const [form, setForm] = useState<HoldingFormData>(emptyForm);
  const [searchQuery, setSearchQuery] = useState("");
  const [sortBy, setSortBy] = useState<string>("name");

  // Fetch real-time prices
  const tickers = useMemo(() => {
    return holdings?.map((h) => h.ticker) || [];
  }, [holdings]);

  const { data: livePrices, isLoading: pricesLoading } =
    trpc.stock.getPrices.useQuery(
      { tickers },
      { enabled: tickers.length > 0, refetchInterval: 5 * 60 * 1000 }
    );

  const refreshMutation = trpc.stock.refreshAll.useMutation({
    onSuccess: (data) => {
      utils.holdings.list.invalidate();
      utils.portfolio.summary.invalidate();
      toast.success(`${data.count}개 종목의 가격이 업데이트되었습니다`);
    },
    onError: () => toast.error("가격 업데이트에 실패했습니다"),
  });

  const createMutation = trpc.holdings.create.useMutation({
    onSuccess: () => {
      utils.holdings.list.invalidate();
      utils.portfolio.summary.invalidate();
      setShowDialog(false);
      setForm(emptyForm);
      toast.success("종목이 추가되었습니다");
    },
    onError: (err) => toast.error(err.message),
  });

  const updateMutation = trpc.holdings.update.useMutation({
    onSuccess: () => {
      utils.holdings.list.invalidate();
      utils.portfolio.summary.invalidate();
      setShowDialog(false);
      setEditingId(null);
      setForm(emptyForm);
      toast.success("종목이 수정되었습니다");
    },
    onError: (err) => toast.error(err.message),
  });

  const deleteMutation = trpc.holdings.delete.useMutation({
    onSuccess: () => {
      utils.holdings.list.invalidate();
      utils.portfolio.summary.invalidate();
      setDeleteId(null);
      toast.success("종목이 삭제되었습니다");
    },
    onError: (err) => toast.error(err.message),
  });

  const filteredHoldings = useMemo(() => {
    if (!holdings) return [];
    let result = [...holdings];

    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      result = result.filter(
        (h) =>
          h.ticker.toLowerCase().includes(q) ||
          h.name.toLowerCase().includes(q)
      );
    }

    result.sort((a, b) => {
      switch (sortBy) {
        case "name":
          return a.name.localeCompare(b.name);
        case "value": {
          const aLive = livePrices?.[a.ticker]?.price;
          const bLive = livePrices?.[b.ticker]?.price;
          const aVal = Number(a.quantity) * (aLive || Number(a.currentPrice) || Number(a.avgPrice));
          const bVal = Number(b.quantity) * (bLive || Number(b.currentPrice) || Number(b.avgPrice));
          return bVal - aVal;
        }
        case "return": {
          const aLive = livePrices?.[a.ticker]?.price;
          const bLive = livePrices?.[b.ticker]?.price;
          const aCur = aLive || Number(a.currentPrice) || Number(a.avgPrice);
          const bCur = bLive || Number(b.currentPrice) || Number(b.avgPrice);
          const aRet = Number(a.avgPrice) > 0 ? (aCur - Number(a.avgPrice)) / Number(a.avgPrice) : 0;
          const bRet = Number(b.avgPrice) > 0 ? (bCur - Number(b.avgPrice)) / Number(b.avgPrice) : 0;
          return bRet - aRet;
        }
        default:
          return 0;
      }
    });

    return result;
  }, [holdings, searchQuery, sortBy, livePrices]);

  // Portfolio totals (real-time)
  const totals = useMemo(() => {
    if (!holdings) return { invested: 0, value: 0, returnRate: 0 };
    let invested = 0;
    let value = 0;
    holdings.forEach((h) => {
      const qty = Number(h.quantity);
      const avg = Number(h.avgPrice);
      const livePrice = livePrices?.[h.ticker]?.price;
      const cur = livePrice || Number(h.currentPrice) || avg;
      invested += qty * avg;
      value += qty * cur;
    });
    const returnRate = invested > 0 ? ((value - invested) / invested) * 100 : 0;
    return { invested, value, returnRate };
  }, [holdings, livePrices]);

  const openEdit = (h: NonNullable<typeof holdings>[0]) => {
    setEditingId(h.id);
    setForm({
      ticker: h.ticker,
      name: h.name,
      quantity: String(h.quantity),
      avgPrice: String(h.avgPrice),
      currentPrice: String(h.currentPrice || ""),
      sector: h.sector || "",
      market: h.market || "",
      currency: h.currency || "KRW",
      dividendYield: String(h.dividendYield || ""),
      notes: h.notes || "",
    });
    setShowDialog(true);
  };

  const handleSubmit = () => {
    if (!form.ticker || !form.name || !form.quantity || !form.avgPrice) {
      toast.error("필수 항목을 입력해주세요");
      return;
    }
    if (editingId) {
      updateMutation.mutate({
        id: editingId,
        ...form,
        currentPrice: form.currentPrice || form.avgPrice,
      });
    } else {
      createMutation.mutate({
        ...form,
        currentPrice: form.currentPrice || form.avgPrice,
      });
    }
  };

  const isMutating = createMutation.isPending || updateMutation.isPending;
  const hasLivePrices = livePrices && Object.keys(livePrices).length > 0;

  // CSV import/export
  const [showImportDialog, setShowImportDialog] = useState(false);
  const [csvContent, setCsvContent] = useState("");

  const { data: exportHoldingsData, refetch: refetchExportHoldings } =
    trpc.csv.exportHoldings.useQuery(undefined, { enabled: false });
  const { data: exportTxData, refetch: refetchExportTx } =
    trpc.csv.exportTransactions.useQuery(undefined, { enabled: false });

  const importMutation = trpc.csv.importHoldings.useMutation({
    onSuccess: (data) => {
      utils.holdings.list.invalidate();
      utils.portfolio.summary.invalidate();
      setShowImportDialog(false);
      setCsvContent("");
      if (data.errors.length > 0) {
        toast.warning(`${data.imported}개 종목 가져옴, ${data.errors.length}개 오류`);
      } else {
        toast.success(`${data.imported}개 종목을 성공적으로 가져왔습니다`);
      }
    },
    onError: (err) => toast.error(err.message),
  });

  const downloadCSV = (csv: string, filename: string) => {
    const BOM = "\uFEFF";
    const blob = new Blob([BOM + csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleExportHoldings = async () => {
    const result = await refetchExportHoldings();
    if (result.data) downloadCSV(result.data.csv, result.data.filename);
  };

  const handleExportTransactions = async () => {
    const result = await refetchExportTx();
    if (result.data) downloadCSV(result.data.csv, result.data.filename);
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      const buffer = await file.arrayBuffer();
      const decoder = new TextDecoder("utf-8", { fatal: true });
      let content = "";
      
      try {
        content = decoder.decode(buffer);
      } catch (e) {
        // Fallback to CP949 (EUC-KR) for Korean Excel CSV files
        const cp949Decoder = new TextDecoder("cp949");
        content = cp949Decoder.decode(buffer);
      }

      // Remove BOM if present
      if (content.charCodeAt(0) === 0xFEFF) {
        content = content.slice(1);
      }
      setCsvContent(content);
    } catch (err) {
      console.error("File read error:", err);
      toast.error("파일을 읽는 중 오류가 발생했습니다.");
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">보유 종목</h1>
          <p className="text-muted-foreground text-sm mt-1">
            {holdings?.length || 0}개 종목 | 총 평가액 {formatCurrency(totals.value)}
            <span className={`ml-2 text-xs font-medium ${totals.returnRate >= 0 ? "text-gain" : "text-loss"}`}>
              ({formatPercent(totals.returnRate)})
            </span>
            {hasLivePrices && (
              <span className="inline-flex items-center gap-1 ml-2 text-primary">
                <Zap className="h-3 w-3" />
                <span className="text-xs">실시간</span>
              </span>
            )}
          </p>
        </div>
        <div className="flex gap-2">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="sm" className="gap-2 bg-transparent">
                <FileSpreadsheet className="h-4 w-4" />
                <span className="hidden sm:inline">CSV</span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={handleExportHoldings} className="gap-2">
                <Download className="h-4 w-4" />
                보유 종목 내보내기
              </DropdownMenuItem>
              <DropdownMenuItem onClick={handleExportTransactions} className="gap-2">
                <Download className="h-4 w-4" />
                거래 이력 내보내기
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setShowImportDialog(true)} className="gap-2">
                <Upload className="h-4 w-4" />
                CSV 가져오기
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
          <Button
            variant="outline"
            size="sm"
            className="gap-2 bg-transparent"
            onClick={() => refreshMutation.mutate()}
            disabled={refreshMutation.isPending || !holdings || holdings.length === 0}
          >
            <RefreshCw className={`h-4 w-4 ${refreshMutation.isPending ? "animate-spin" : ""}`} />
            <span className="hidden sm:inline">{refreshMutation.isPending ? "업데이트 중..." : "가격 새로고침"}</span>
          </Button>
          <Button
            onClick={() => {
              setEditingId(null);
              setForm(emptyForm);
              setShowDialog(true);
            }}
            className="gap-2"
          >
            <Plus className="h-4 w-4" />
            종목 추가
          </Button>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="종목명 또는 티커 검색..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9 bg-secondary/50"
          />
        </div>
        <Select value={sortBy} onValueChange={setSortBy}>
          <SelectTrigger className="w-[160px] bg-secondary/50">
            <SelectValue placeholder="정렬" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="name">이름순</SelectItem>
            <SelectItem value="value">평가액순</SelectItem>
            <SelectItem value="return">수익률순</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Holdings Table */}
      <Card className="bg-card border-border">
        <CardContent className="p-0">
          {isLoading ? (
            <div className="p-6 space-y-4">
              {[...Array(5)].map((_, i) => (
                <Skeleton key={i} className="h-14 w-full" />
              ))}
            </div>
          ) : filteredHoldings.length === 0 ? (
            <div className="p-12 text-center text-muted-foreground">
              <Search className="h-10 w-10 mx-auto mb-3 opacity-30" />
              <p className="font-medium">
                {searchQuery ? "검색 결과가 없습니다" : "보유 종목이 없습니다"}
              </p>
              <p className="text-xs mt-1">
                {searchQuery
                  ? "다른 검색어를 시도해보세요"
                  : '"종목 추가" 버튼으로 시작하세요'}
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border">
                    <th className="text-left py-3 px-4 text-muted-foreground font-medium text-xs uppercase tracking-wider">
                      종목
                    </th>
                    <th className="text-right py-3 px-4 text-muted-foreground font-medium text-xs uppercase tracking-wider">
                      수량
                    </th>
                    <th className="text-right py-3 px-4 text-muted-foreground font-medium text-xs uppercase tracking-wider hidden md:table-cell">
                      평균매수가
                    </th>
                    <th className="text-right py-3 px-4 text-muted-foreground font-medium text-xs uppercase tracking-wider">
                      현재가
                    </th>
                    <th className="text-right py-3 px-4 text-muted-foreground font-medium text-xs uppercase tracking-wider hidden sm:table-cell">
                      평가금액
                    </th>
                    <th className="text-right py-3 px-4 text-muted-foreground font-medium text-xs uppercase tracking-wider">
                      수익률
                    </th>
                    <th className="text-right py-3 px-4 text-muted-foreground font-medium text-xs uppercase tracking-wider">
                      작업
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {filteredHoldings.map((h) => {
                    const avg = Number(h.avgPrice);
                    const livePrice = livePrices?.[h.ticker]?.price;
                    const cur = livePrice || Number(h.currentPrice) || avg;
                    const qty = Number(h.quantity);
                    const totalValue = qty * cur;
                    const returnRate =
                      avg > 0 ? ((cur - avg) / avg) * 100 : 0;
                    const isGain = returnRate >= 0;
                    const priceChange = livePrices?.[h.ticker]?.changePercent;

                    return (
                      <tr
                        key={h.id}
                        className="border-b border-border/50 hover:bg-accent/30 transition-colors group"
                      >
                        <td className="py-3 px-4">
                          <button
                            onClick={() => setLocation(`/holdings/${h.id}`)}
                            className="text-left focus:outline-none"
                          >
                            <div className="font-semibold flex items-center gap-1.5">
                              {h.ticker}
                              {livePrice && <Zap className="h-3 w-3 text-primary opacity-50" />}
                              <ExternalLink className="h-3 w-3 opacity-0 group-hover:opacity-50 transition-opacity" />
                            </div>
                            <div className="text-xs text-muted-foreground mt-0.5">
                              {h.name}
                            </div>
                          </button>
                        </td>
                        <td className="py-3 px-4 text-right tabular-nums">
                          {qty.toLocaleString()}
                        </td>
                        <td className="py-3 px-4 text-right tabular-nums hidden md:table-cell">
                          {formatCurrency(avg)}
                        </td>
                        <td className="py-3 px-4 text-right">
                          <div className="tabular-nums">{formatCurrency(cur)}</div>
                          {priceChange !== undefined && priceChange !== null && (
                            <div className={`text-xs tabular-nums ${priceChange >= 0 ? "text-gain" : "text-loss"}`}>
                              {priceChange >= 0 ? "+" : ""}{priceChange.toFixed(2)}%
                            </div>
                          )}
                        </td>
                        <td className="py-3 px-4 text-right tabular-nums hidden sm:table-cell">
                          {formatCurrency(totalValue)}
                        </td>
                        <td className="py-3 px-4 text-right">
                          <span
                            className={`inline-flex items-center gap-1 text-xs font-medium px-2 py-0.5 rounded-full ${
                              isGain
                                ? "text-gain bg-gain"
                                : "text-loss bg-loss"
                            }`}
                          >
                            {isGain ? (
                              <TrendingUp className="h-3 w-3" />
                            ) : (
                              <TrendingDown className="h-3 w-3" />
                            )}
                            {formatPercent(returnRate)}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-right">
                          <div className="flex items-center justify-end gap-1">
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-8 w-8 text-muted-foreground hover:text-foreground"
                              onClick={() => openEdit(h)}
                            >
                              <Pencil className="h-3.5 w-3.5" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-8 w-8 text-muted-foreground hover:text-destructive"
                              onClick={() => setDeleteId(h.id)}
                            >
                              <Trash2 className="h-3.5 w-3.5" />
                            </Button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Add/Edit Dialog */}
      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="sm:max-w-[500px] bg-card border-border">
          <DialogHeader>
            <DialogTitle>
              {editingId ? "종목 수정" : "종목 추가"}
            </DialogTitle>
            <DialogDescription>
              {editingId
                ? "보유 종목 정보를 수정합니다"
                : "새로운 종목을 포트폴리오에 추가합니다"}
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="ticker">티커 *</Label>
                <Input
                  id="ticker"
                  placeholder="예: AAPL"
                  value={form.ticker}
                  onChange={(e) =>
                    setForm({ ...form, ticker: e.target.value })
                  }
                  className="bg-secondary/50"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="name">종목명 *</Label>
                <Input
                  id="name"
                  placeholder="예: Apple Inc."
                  value={form.name}
                  onChange={(e) =>
                    setForm({ ...form, name: e.target.value })
                  }
                  className="bg-secondary/50"
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="quantity">수량 *</Label>
                <Input
                  id="quantity"
                  type="number"
                  placeholder="0"
                  value={form.quantity}
                  onChange={(e) =>
                    setForm({ ...form, quantity: e.target.value })
                  }
                  className="bg-secondary/50"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="avgPrice">평균매수가 *</Label>
                <Input
                  id="avgPrice"
                  type="number"
                  placeholder="0"
                  value={form.avgPrice}
                  onChange={(e) =>
                    setForm({ ...form, avgPrice: e.target.value })
                  }
                  className="bg-secondary/50"
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="currentPrice">현재가</Label>
                <Input
                  id="currentPrice"
                  type="number"
                  placeholder="자동 조회 (미입력시)"
                  value={form.currentPrice}
                  onChange={(e) =>
                    setForm({ ...form, currentPrice: e.target.value })
                  }
                  className="bg-secondary/50"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="currency">통화</Label>
                <Select
                  value={form.currency}
                  onValueChange={(v) => setForm({ ...form, currency: v })}
                >
                  <SelectTrigger className="bg-secondary/50">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="KRW">KRW (원)</SelectItem>
                    <SelectItem value="USD">USD ($)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="sector">섹터</Label>
                <Input
                  id="sector"
                  placeholder="예: 기술"
                  value={form.sector}
                  onChange={(e) =>
                    setForm({ ...form, sector: e.target.value })
                  }
                  className="bg-secondary/50"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="market">시장</Label>
                <Input
                  id="market"
                  placeholder="예: KOSPI"
                  value={form.market}
                  onChange={(e) =>
                    setForm({ ...form, market: e.target.value })
                  }
                  className="bg-secondary/50"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="dividendYield">배당수익률 (%)</Label>
              <Input
                id="dividendYield"
                type="number"
                step="0.01"
                placeholder="0.00"
                value={form.dividendYield}
                onChange={(e) =>
                  setForm({ ...form, dividendYield: e.target.value })
                }
                className="bg-secondary/50"
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setShowDialog(false)}
              className="bg-transparent"
            >
              취소
            </Button>
            <Button onClick={handleSubmit} disabled={isMutating}>
              {isMutating ? "저장 중..." : editingId ? "수정" : "추가"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* CSV Import Dialog */}
      <Dialog open={showImportDialog} onOpenChange={setShowImportDialog}>
        <DialogContent className="sm:max-w-[500px] bg-card border-border">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Upload className="h-5 w-5" />
              CSV 가져오기
            </DialogTitle>
            <DialogDescription>
              CSV 파일을 업로드하여 보유 종목을 일괄 등록합니다. 필수 컬럼: ticker, name, quantity, avgPrice
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="border-2 border-dashed border-border rounded-lg p-6 text-center">
              <FileSpreadsheet className="h-10 w-10 mx-auto mb-3 text-muted-foreground" />
              <label className="cursor-pointer">
                <span className="text-sm text-primary hover:underline">파일 선택</span>
                <input
                  type="file"
                  accept=".csv"
                  onChange={handleFileUpload}
                  className="hidden"
                />
              </label>
              <p className="text-xs text-muted-foreground mt-2">또는 아래에 CSV 내용을 직접 붙여넣기</p>
            </div>
            <textarea
              value={csvContent}
              onChange={(e) => setCsvContent(e.target.value)}
              placeholder={"ticker,name,quantity,avgPrice\nAAPL,Apple Inc.,10,150.00\nTSLA,Tesla Inc.,5,200.00"}
              className="w-full h-32 rounded-lg border border-border bg-secondary/50 p-3 text-sm font-mono resize-none focus:outline-none focus:ring-2 focus:ring-ring"
            />
            {csvContent && (
              <p className="text-xs text-muted-foreground">
                {csvContent.trim().split("\n").length - 1}개 행 감지됨
              </p>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => { setShowImportDialog(false); setCsvContent(""); }} className="bg-transparent">
              취소
            </Button>
            <Button
              onClick={() => importMutation.mutate({ csvContent })}
              disabled={!csvContent.trim() || importMutation.isPending}
              className="gap-2"
            >
              <Upload className="h-4 w-4" />
              {importMutation.isPending ? "가져오는 중..." : "가져오기"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <AlertDialog open={deleteId !== null} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent className="bg-card border-border">
          <AlertDialogHeader>
            <AlertDialogTitle>종목 삭제</AlertDialogTitle>
            <AlertDialogDescription>
              이 종목과 관련된 모든 거래 이력이 삭제됩니다. 이 작업은 되돌릴 수
              없습니다.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="bg-transparent">취소</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => deleteId && deleteMutation.mutate({ id: deleteId })}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              삭제
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
