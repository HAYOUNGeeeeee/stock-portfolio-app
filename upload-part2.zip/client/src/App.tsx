import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import DashboardLayout from "./components/DashboardLayout";
import Home from "./pages/Home";
import Holdings from "./pages/Holdings";
import Analysis from "./pages/Analysis";
import HoldingDetail from "./pages/HoldingDetail";
import Scenario from "./pages/Scenario";
import Rebalancing from "./pages/Rebalancing";
import Alerts from "./pages/Alerts";

function Router() {
  return (
    <DashboardLayout>
      <Switch>
        <Route path={"/"} component={Home} />
        <Route path={"/holdings"} component={Holdings} />
        <Route path={"/analysis"} component={Analysis} />
        <Route path={"/scenario"} component={Scenario} />
        <Route path={"/rebalancing"} component={Rebalancing} />
        <Route path={"/alerts"} component={Alerts} />
        <Route path={"/holdings/:id"} component={HoldingDetail} />
        <Route path={"/404"} component={NotFound} />
        <Route component={NotFound} />
      </Switch>
    </DashboardLayout>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
